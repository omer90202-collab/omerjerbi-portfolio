#!/usr/bin/env python3
"""
dm-autopilot · builds the delivery page (one self-contained Hebrew RTL index.html)
from assets/delivery-page.html and the `delivery_page` block of config.json.

  python3 scripts/build_page.py              build into <skill>/<out_dir>/
  python3 scripts/build_page.py --open       build and open in the browser
  python3 scripts/build_page.py --config X   use another config file

Standard library only. Output folder is ready for Netlify Drop or `vercel deploy`.
"""

import argparse
import html
import json
import os
import re
import shutil
import sys
import webbrowser

SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATE = os.path.join(SKILL_ROOT, "assets", "delivery-page.html")
DEFAULT_CONFIG = os.path.join(SKILL_ROOT, "config.json")

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def fail(msg):
    print(msg, file=sys.stderr)
    sys.exit(2)


def placeholder(v):
    return isinstance(v, str) and "<" in v and ">" in v


def ink_for(hex_color):
    """Black or white text on the brand color, whichever reads better (WCAG luminance)."""
    m = re.fullmatch(r"#?([0-9a-fA-F]{6})", hex_color.strip())
    if not m:
        fail("brand_color צריך להיות בפורמט #RRGGBB (קיבלתי: %s)" % hex_color)
    r, g, b = (int(m.group(1)[i:i + 2], 16) / 255 for i in (0, 2, 4))

    def lin(c):
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4

    lum = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
    return "#0b0b0d" if lum > 0.42 else "#ffffff"


def video_embed(url):
    """Returns (embed_html, extra_class) for YouTube / Shorts / Vimeo / Loom / direct mp4."""
    if not url:
        return None, ""
    e = html.escape
    yt = re.search(r"(?:youtube\.com/(?:watch\?v=|shorts/|embed/)|youtu\.be/)([A-Za-z0-9_-]{6,})", url)
    if yt:
        vertical = "/shorts/" in url
        src = "https://www.youtube-nocookie.com/embed/%s?rel=0&modestbranding=1&playsinline=1" % yt.group(1)
        return ('      <iframe src="%s" title="סרטון הדרכה" loading="lazy" allow="accelerometer; encrypted-media; '
                'gyroscope; picture-in-picture; fullscreen" allowfullscreen></iframe>' % e(src),
                " vertical" if vertical else "")
    vm = re.search(r"vimeo\.com/(?:video/)?(\d+)", url)
    if vm:
        src = "https://player.vimeo.com/video/%s?dnt=1" % vm.group(1)
        return ('      <iframe src="%s" title="סרטון הדרכה" loading="lazy" allow="fullscreen; picture-in-picture" '
                'allowfullscreen></iframe>' % e(src), "")
    lm = re.search(r"loom\.com/(?:share|embed)/([A-Za-z0-9]+)", url)
    if lm:
        src = "https://www.loom.com/embed/%s" % lm.group(1)
        return '      <iframe src="%s" title="סרטון הדרכה" loading="lazy" allowfullscreen></iframe>' % e(src), ""
    if re.search(r"\.(mp4|webm|mov)(\?|$)", url, re.I):
        return '      <video src="%s" controls playsinline preload="metadata"></video>' % e(url), ""
    fail("לא זיהיתי את הסרטון (%s). נתמך: YouTube / Shorts / Vimeo / Loom / קישור ישיר ל-mp4." % url)


def cut_block(page, name):
    return re.sub(r"\s*<!--%s-->.*?<!--/%s-->" % (name, name), "", page, flags=re.S)


def keep_block(page, name):
    return page.replace("<!--%s-->" % name, "").replace("<!--/%s-->" % name, "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=DEFAULT_CONFIG)
    ap.add_argument("--open", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.config):
        fail("אין config.json - קודם הראיון.")
    with open(args.config, encoding="utf-8") as fh:
        cfg = json.load(fh)
    d = cfg.get("delivery_page") or {}

    required = ["title", "subtitle", "cta_label", "handle"]
    missing = [k for k in required if not d.get(k) or placeholder(d.get(k))]
    if missing:
        fail("חסר ב-delivery_page: " + ", ".join(missing))

    out_dir = os.path.join(SKILL_ROOT, d.get("out_dir") or "delivery-page-out")
    os.makedirs(out_dir, exist_ok=True)

    # Where the big button points: a hosted link, or a local file shipped next to the page.
    local_file = (d.get("local_file") or "").strip()
    cta_url = (d.get("cta_url") or "").strip()
    attrs = ' target="_blank" rel="noopener"'
    if local_file:
        src = os.path.expanduser(local_file)
        if not os.path.isfile(src):
            fail("הקובץ לא נמצא: %s" % src)
        name = re.sub(r"[^A-Za-z0-9._-]+", "-", os.path.basename(src)).strip("-") or "download"
        size_mb = os.path.getsize(src) / 1_000_000
        if size_mb > 50:
            print("  [!] הקובץ %.0fMB - כבד לאחסון חינמי. עדיף להעלות לגוגל דרייב ולשים קישור ב-cta_url." % size_mb)
        shutil.copy2(src, os.path.join(out_dir, name))
        cta_href, attrs = name, ' download="%s"' % html.escape(name)
    elif cta_url and not placeholder(cta_url):
        if not cta_url.startswith("https://"):
            fail("cta_url חייב להתחיל ב-https://")
        cta_href = cta_url
    else:
        fail("צריך cta_url (קישור) או local_file (קובץ להורדה).")

    handle = d["handle"].strip()
    if not handle.startswith("@"):
        handle = "@" + handle
    ig_url = d.get("instagram_url") or ""
    if not ig_url or placeholder(ig_url):
        ig_url = "https://instagram.com/" + handle.lstrip("@")

    brand = d.get("brand_color") or "#7C5CFF"
    if not brand.startswith("#"):
        brand = "#" + brand
    theme = "light" if (d.get("theme") or "dark") == "light" else "dark"

    with open(TEMPLATE, encoding="utf-8") as fh:
        page = fh.read()

    bullets = [b for b in (d.get("bullets") or []) if isinstance(b, str) and b.strip() and not placeholder(b)]
    if bullets:
        page = keep_block(page, "BULLETS")
        page = page.replace("{{BULLETS}}", "\n".join("      <li>%s</li>" % html.escape(b) for b in bullets[:6]))
    else:
        page = cut_block(page, "BULLETS")

    embed, vclass = video_embed((d.get("video_url") or "").strip())
    if embed:
        page = keep_block(page, "VIDEO")
        page = page.replace("{{VIDEO_EMBED}}", embed).replace("{{VIDEO_CLASS}}", vclass)
    else:
        page = cut_block(page, "VIDEO")

    e = html.escape
    values = {
        "THEME": theme,
        "TITLE": e(d["title"]),
        "SUBTITLE": e(d["subtitle"]),
        "SUBTITLE_PLAIN": e(d["subtitle"]),
        "BRAND": e(brand),
        "BRAND_INK": ink_for(brand),
        "BADGE": e(d["badge"]) if d.get("badge") else 'מתנה מ-<bdi dir="ltr">%s</bdi>' % e(handle),
        "CTA_LABEL": e(d["cta_label"]),
        "CTA_HREF": e(cta_href),
        "CTA_ATTRS": attrs,
        "FINE_PRINT": e(d.get("fine_print") or "חינם. בלי הרשמה. תהנו."),
        "HANDLE": e(handle),
        "IG_URL": e(ig_url),
    }
    for k, v in values.items():
        page = page.replace("{{%s}}" % k, v)
    leftover = re.findall(r"\{\{[A-Z_]+\}\}", page)
    if leftover:
        fail("נשארו שדות לא ממולאים בתבנית: " + ", ".join(sorted(set(leftover))))

    out = os.path.join(out_dir, "index.html")
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(page)
    # Belt and braces: also tell crawlers via robots.txt.
    with open(os.path.join(out_dir, "robots.txt"), "w", encoding="utf-8") as fh:
        fh.write("User-agent: *\nDisallow: /\n")

    print("העמוד מוכן: %s" % out)
    print("תיקייה להעלאה: %s" % out_dir)
    if args.open:
        webbrowser.open("file://" + out)


if __name__ == "__main__":
    main()
