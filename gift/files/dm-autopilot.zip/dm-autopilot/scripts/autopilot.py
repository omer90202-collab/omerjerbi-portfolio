#!/usr/bin/env python3
"""
dm-autopilot · Instagram "comment a word -> get the link in DM", driven by the Zernio API.

Standard library only. The API key lives in a `.env` file at the skill root
(ZERNIO_API_KEY=sk_...), never in this file and never in config.json.

Commands (run from anywhere):
  python3 scripts/autopilot.py doctor                 offline health check (.env, config, rules)
  python3 scripts/autopilot.py profiles               list Zernio profiles
  python3 scripts/autopilot.py accounts               list connected Instagram accounts
  python3 scripts/autopilot.py connect --profile ID   get the Instagram connect link
  python3 scripts/autopilot.py posts --account ID     latest 25 posts (to find the post id)
  python3 scripts/autopilot.py find-post URL          match a post link to its platform id
  python3 scripts/autopilot.py plan                   validate config + show the exact payload (no network)
  python3 scripts/autopilot.py push --confirm כן      create, or update if it already exists (idempotent)
  python3 scripts/autopilot.py rules                  list automations on the account
  python3 scripts/autopilot.py show ID                one automation + stats
  python3 scripts/autopilot.py logs ID                who triggered it, and what was sent
  python3 scripts/autopilot.py pause ID | resume ID   switch an automation off / on
  python3 scripts/autopilot.py remove ID --confirm כן delete an automation
  python3 scripts/autopilot.py checklist              live test checklist (Hebrew)

Global flags:
  --config PATH   config file (default: <skill>/config.json)
  --dry-run       print every request (key masked) instead of sending it

Endpoints follow docs.zernio.com (checked 2026-10-01). Base URL can be overridden with
ZERNIO_BASE_URL in .env if Zernio ever moves it.
"""

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

SKILL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_PATH = os.path.join(SKILL_ROOT, ".env")
DEFAULT_CONFIG = os.path.join(SKILL_ROOT, "config.json")
DEFAULT_BASE = "https://zernio.com/api/v1"
CONFIRM_WORD = "כן"

# Limits taken from the Zernio comment-automation reference.
MAX_BUTTON_TITLE = 20
MAX_DM_WITH_BUTTON = 640
MAX_DM_PLAIN = 1000
MAX_VARIATIONS = 5
MAX_GATE_MESSAGE = 640
MAX_NOT_FOLLOWING = 1000
SHORT_KEYWORD = 4  # below this, "contains" matching misfires and typo tolerance is off

if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass


# ---------------------------------------------------------------- output helpers

def say(msg=""):
    print(msg)


def ok(msg):
    print("  [OK]   " + msg)


def warn(msg):
    print("  [!]    " + msg)


def bad(msg):
    print("  [X]    " + msg)


class Stop(Exception):
    """A clean, human-readable failure. Printed without a traceback."""


# ---------------------------------------------------------------- .env + config

def read_env():
    values = {}
    if not os.path.exists(ENV_PATH):
        return values
    with open(ENV_PATH, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            values[k.strip()] = v.strip().strip('"').strip("'")
    return values


def api_settings(dry_run):
    env = read_env()
    key = os.environ.get("ZERNIO_API_KEY") or env.get("ZERNIO_API_KEY", "")
    base = (os.environ.get("ZERNIO_BASE_URL") or env.get("ZERNIO_BASE_URL") or DEFAULT_BASE).rstrip("/")
    if not key and not dry_run:
        raise Stop(
            "לא מצאתי מפתח API.\n"
            "  צור קובץ בשם .env בתיקיית הסקיל (%s)\n"
            "  ושים בו שורה אחת:  ZERNIO_API_KEY=sk_...\n"
            "  את המפתח מייצרים ב-Zernio: Dashboard -> API Keys." % SKILL_ROOT
        )
    return key or "sk_dry_run_placeholder", base


def mask(key):
    if len(key) <= 8:
        return "****"
    return key[:5] + "…" + key[-4:]


def load_config(path):
    if not os.path.exists(path):
        raise Stop(
            "אין קובץ config.json (%s).\n"
            "  העתק את config.example.json ל-config.json ומלא אותו, או תן לקלוד להריץ את הראיון." % path
        )
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except json.JSONDecodeError as exc:
        raise Stop("config.json לא תקין (JSON): שורה %d, עמודה %d - %s" % (exc.lineno, exc.colno, exc.msg))


def g(cfg, dotted, default=None):
    cur = cfg
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return default
        cur = cur[part]
    return cur if cur not in ("", None) else default


def is_placeholder(value):
    return isinstance(value, str) and ("<" in value or "PASTE" in value.upper() or "XXXX" in value.upper())


# ---------------------------------------------------------------- validation

def validate(cfg):
    """Returns (errors, warnings). Errors block a push; warnings are shown."""
    errors, warnings = [], []

    name = g(cfg, "rule_name")
    if not name or is_placeholder(name):
        errors.append("rule_name חסר - שם פנימי לחוק (למשל: 'מדריך פרומפטים - ריל 14/10').")

    for field in ("zernio.profile_id", "zernio.account_id"):
        val = g(cfg, field)
        if not val or is_placeholder(val):
            errors.append("%s חסר - הרץ `accounts` כדי לקבל אותו." % field)

    post_id = g(cfg, "post.platform_post_id")
    account_wide = bool(g(cfg, "post.account_wide", False))
    if (not post_id or is_placeholder(post_id)) and not account_wide:
        errors.append(
            "post.platform_post_id חסר. חוק בלי פוסט ספציפי יופעל על כל הפוסטים בחשבון.\n"
            "         הרץ `find-post <קישור לפוסט>` כדי למצוא אותו. (אם באמת רוצים לכל החשבון: post.account_wide=true)"
        )
    if account_wide:
        warnings.append("החוק יופעל על כל פוסט בחשבון (account_wide). ודא שמילת המפתח ייחודית מאוד.")

    keywords = [k.strip() for k in (g(cfg, "trigger.keywords", []) or []) if isinstance(k, str) and k.strip()]
    match = g(cfg, "trigger.match", "word")
    if match not in ("word", "exact", "contains"):
        errors.append("trigger.match חייב להיות word / exact / contains.")
    if not keywords:
        errors.append("trigger.keywords ריק - בלי מילת מפתח כל תגובה תפעיל DM. תן לפחות מילה אחת.")
    for kw in keywords:
        if is_placeholder(kw):
            errors.append("מילת מפתח עדיין placeholder: %s" % kw)
        elif len(kw) < SHORT_KEYWORD and match == "contains":
            errors.append(
                "'%s' קצרה מדי למצב contains - היא תיתפס בתוך מילים אחרות. החלף ל-match=word או למילה ארוכה יותר." % kw
            )
        elif len(kw) < SHORT_KEYWORD:
            warnings.append("'%s' קצרה (פחות מ-4 תווים) - אין לה סבלנות לשגיאות הקלדה. שקול מילה ארוכה יותר." % kw)
        if " " in kw and not is_placeholder(kw):
            warnings.append("'%s' כוללת רווח - אנשים מקלידים ביטויים בכל מיני צורות. מילה אחת עדיפה." % kw)
    common = {"אש", "וואו", "מדהים", "תודה", "כן", "link", "wow", "fire", "yes", "love"}
    for kw in keywords:
        if kw.lower() in common:
            errors.append("'%s' היא מילה שאנשים כותבים ממילא - החוק יירה על תגובות רגילות. בחר מילה ייחודית." % kw)
    if g(cfg, "trigger.typo_tolerance") and match != "word":
        warnings.append("typo_tolerance עובד רק עם match=word - יתעלמו ממנו.")

    dm_text = g(cfg, "dm.text", "")
    link = g(cfg, "dm.link")
    label = g(cfg, "dm.button_label")
    if not dm_text or is_placeholder(dm_text):
        errors.append("dm.text חסר - זו ההודעה שתישלח בפרטי.")
    if link:
        if is_placeholder(link):
            errors.append("dm.link עדיין placeholder - קודם מעלים את עמוד המסירה ומדביקים כאן את הכתובת.")
        elif not link.startswith("https://"):
            errors.append("dm.link חייב להתחיל ב-https://")
        if not label or is_placeholder(label):
            errors.append("dm.button_label חסר - הטקסט על הכפתור (עד 20 תווים).")
        elif len(label) > MAX_BUTTON_TITLE:
            errors.append("dm.button_label ארוך מדי (%d/20): '%s'" % (len(label), label))
        if dm_text and len(dm_text) > MAX_DM_WITH_BUTTON:
            errors.append("dm.text ארוך מדי להודעה עם כפתור (%d/640)." % len(dm_text))
    else:
        warnings.append("אין dm.link - תישלח הודעת טקסט בלי כפתור.")
        if dm_text and len(dm_text) > MAX_DM_PLAIN:
            errors.append("dm.text ארוך מדי (%d/~1000)." % len(dm_text))
    if dm_text and link and link in dm_text:
        warnings.append("הקישור מופיע גם בגוף ההודעה. עדיף רק בכפתור - נקי יותר ופחות 'ספאמי'.")

    variations = g(cfg, "dm.variations", []) or []
    if len(variations) > MAX_VARIATIONS:
        errors.append("dm.variations - עד 5 נוסחים.")
    for v in variations:
        if link and len(v) > MAX_DM_WITH_BUTTON:
            errors.append("אחד מנוסחי dm.variations ארוך מ-640 תווים.")
    if not variations:
        warnings.append("אין dm.variations. 2-3 נוסחים מתחלפים מורידים את הסיכוי שמטא תסמן את זה כספאם.")

    reply = g(cfg, "public_reply.text")
    reply_vars = g(cfg, "public_reply.variations", []) or []
    if len(reply_vars) > MAX_VARIATIONS:
        errors.append("public_reply.variations - עד 5 נוסחים.")
    if reply and ("http" in reply or "www." in reply):
        errors.append("אל תשים קישור בתגובה הציבורית - הקישור הולך רק לפרטי.")

    gate = g(cfg, "follow_gate.mode", "off")
    if gate not in ("off", "verify", "tap"):
        errors.append("follow_gate.mode חייב להיות off / verify / tap.")
    gmsg = g(cfg, "follow_gate.message", "")
    if gmsg and len(gmsg) > MAX_GATE_MESSAGE:
        errors.append("follow_gate.message ארוך מדי (%d/640)." % len(gmsg))
    glabel = g(cfg, "follow_gate.button_label", "")
    if glabel and len(glabel) > MAX_BUTTON_TITLE:
        errors.append("follow_gate.button_label ארוך מדי (%d/20)." % len(glabel))
    nf = g(cfg, "follow_gate.not_following_message", "")
    if nf and len(nf) > MAX_NOT_FOLLOWING:
        errors.append("follow_gate.not_following_message ארוך מדי.")
    if gate == "verify" and not gmsg:
        warnings.append("follow_gate=verify בלי הודעה משלך - Zernio ישלח נוסח ברירת מחדל באנגלית. מומלץ לכתוב בעברית.")

    delay = g(cfg, "dm.delay_seconds", 0) or 0
    if not isinstance(delay, int) or delay < 0 or delay > 86400:
        errors.append("dm.delay_seconds בין 0 ל-86400.")

    return errors, warnings


# ---------------------------------------------------------------- payload

def build_payload(cfg):
    """Translate our config into the Zernio create/patch body."""
    keywords = [k.strip() for k in g(cfg, "trigger.keywords", []) if isinstance(k, str) and k.strip()]
    match = g(cfg, "trigger.match", "word")
    body = {
        "profileId": g(cfg, "zernio.profile_id"),
        "accountId": g(cfg, "zernio.account_id"),
        "name": g(cfg, "rule_name"),
        "trigger": "comment",
        "keywords": keywords,
        "matchMode": match,
        "dmMessage": g(cfg, "dm.text"),
    }
    if not g(cfg, "post.account_wide", False):
        body["platformPostId"] = g(cfg, "post.platform_post_id")
        caption = g(cfg, "post.caption_hint")
        if caption:
            body["postTitle"] = caption[:120]
    exclude = g(cfg, "trigger.exclude", []) or []
    if exclude:
        body["excludeKeywords"] = exclude
    if match == "word" and g(cfg, "trigger.typo_tolerance", False):
        body["typoTolerance"] = True
    if g(cfg, "trigger.also_in_dms", False) and keywords:
        body["alsoMatchInDms"] = True

    link = g(cfg, "dm.link")
    if link:
        body["buttons"] = [{"type": "url", "title": g(cfg, "dm.button_label"), "url": link}]
    variations = g(cfg, "dm.variations", []) or []
    if variations:
        body["dmMessageVariations"] = variations
    delay = g(cfg, "dm.delay_seconds", 0) or 0
    if delay:
        body["dmDelaySeconds"] = delay
    tracking = g(cfg, "dm.track_clicks", None)
    if tracking is not None:
        body["linkTracking"] = bool(tracking)

    reply = g(cfg, "public_reply.text")
    if reply:
        body["commentReply"] = reply
        rv = g(cfg, "public_reply.variations", []) or []
        if rv:
            body["commentReplyVariations"] = rv

    gate = g(cfg, "follow_gate.mode", "off")
    gate_copy = {}
    for src, dst in (("message", "message"), ("button_label", "buttonLabel"),
                     ("not_following_message", "notFollowingMessage")):
        val = g(cfg, "follow_gate." + src)
        if val:
            gate_copy[dst] = val
    if gate == "verify":
        body["audience"] = {"followerStatus": "follower", "whenUnknown": "verify"}
        if gate_copy:
            body["followGate"] = gate_copy
    elif gate == "tap":
        body["audience"] = {"followerStatus": "any", "tapToUnlock": True}
        if gate_copy:
            body["followGate"] = gate_copy
    return body


# ---------------------------------------------------------------- HTTP

class Api:
    def __init__(self, key, base, dry_run):
        self.key, self.base, self.dry_run = key, base, dry_run

    def call(self, method, path, query=None, body=None, write=False):
        url = self.base + path
        if query:
            url += "?" + urllib.parse.urlencode({k: v for k, v in query.items() if v not in (None, "")})
        if self.dry_run:
            say("\n[dry-run] %s %s" % (method, url))
            say("[dry-run] Authorization: Bearer %s" % mask(self.key))
            if body is not None:
                say("[dry-run] body:\n" + json.dumps(body, ensure_ascii=False, indent=2))
            if write:
                say("[dry-run] לא נשלח כלום.")
            return None
        data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Authorization", "Bearer " + self.key)
        req.add_header("Accept", "application/json")
        req.add_header("User-Agent", "dm-autopilot/1.0")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        for attempt in range(3):
            try:
                with urllib.request.urlopen(req, timeout=30) as resp:
                    raw = resp.read().decode("utf-8") or "{}"
                    return json.loads(raw)
            except urllib.error.HTTPError as exc:
                text = exc.read().decode("utf-8", "replace")
                # Only retry reads; a retried write could double-create.
                if exc.code in (429, 503) and not write and attempt < 2:
                    wait = int(exc.headers.get("Retry-After", "3") or 3)
                    warn("Zernio עמוס (%d), מנסה שוב בעוד %d שניות..." % (exc.code, wait))
                    time.sleep(min(wait, 20))
                    continue
                raise Stop(explain_http(exc.code, text, write))
            except urllib.error.URLError as exc:
                raise Stop("אין חיבור ל-Zernio (%s). בדוק אינטרנט / VPN." % exc.reason)
        raise Stop("Zernio לא ענה אחרי 3 ניסיונות.")


def explain_http(code, text, write):
    detail = ""
    try:
        payload = json.loads(text)
        detail = payload.get("error") or payload.get("message") or ""
        pe = payload.get("platformError") or {}
        if isinstance(pe, dict) and pe.get("error_user_msg"):
            detail += " | Meta: " + pe["error_user_msg"]
        if payload.get("param"):
            detail += " (שדה: %s)" % payload["param"]
    except Exception:
        detail = text[:300]
    hints = {
        400: "הבקשה נדחתה - כנראה שדה לא תקין. הפרטים:",
        401: "המפתח לא תקף. בדוק את ZERNIO_API_KEY ב-.env (צריך להתחיל ב-sk_).",
        403: "אין הרשאה - ייתכן שהמפתח מוגבל לפרופיל אחר, או שנגמרה מכסת החשבונות בתוכנית.",
        404: "לא נמצא - ה-ID שגוי או שהאוטומציה כבר נמחקה.",
        409: "כבר קיימת אוטומציה פעילה על הפוסט הזה. הרץ `rules`, ואז עדכן אותה או השהה אותה.",
        429: "יותר מדי בקשות. חכה דקה ונסה שוב.",
        503: "Zernio זמנית לא זמין.",
    }
    msg = "Zernio החזיר %d. %s" % (code, hints.get(code, ""))
    if detail:
        msg += "\n  " + detail
    if write and code in (503, 504):
        msg += "\n  ייתכן שהפעולה בכל זאת נקלטה. הרץ `rules` לפני שמנסים שוב."
    return msg


def items(resp, *keys):
    if resp is None:
        return []
    for k in keys:
        if isinstance(resp, dict) and isinstance(resp.get(k), list):
            return resp[k]
    if isinstance(resp, list):
        return resp
    return []


def rid(obj):
    return obj.get("id") or obj.get("_id") or ""


# ---------------------------------------------------------------- commands

def cmd_doctor(args):
    say("בדיקת מערכת (בלי רשת):")
    problems = 0
    env = read_env()
    key = os.environ.get("ZERNIO_API_KEY") or env.get("ZERNIO_API_KEY", "")
    if not os.path.exists(ENV_PATH):
        bad("אין קובץ .env בתיקיית הסקיל.")
        problems += 1
    elif not key:
        bad(".env קיים אבל אין בו ZERNIO_API_KEY.")
        problems += 1
    elif not re.fullmatch(r"sk_[0-9a-fA-F]{64}", key):
        warn("יש מפתח (%s) אבל הפורמט לא כמו בתיעוד (sk_ + 64 תווים). אולי הודבק חלקית." % mask(key))
    else:
        ok("מפתח API נמצא (%s)." % mask(key))
    if os.path.exists(ENV_PATH):
        try:
            mode = os.stat(ENV_PATH).st_mode & 0o777
            if mode & 0o077:
                warn(".env פתוח לקריאה למשתמשים אחרים. מומלץ: chmod 600 .env")
        except OSError:
            pass
    if not os.path.exists(args.config):
        warn("אין config.json עדיין - זה בסדר אם עוד לא עשית את הראיון.")
        return 1 if problems else 0
    cfg = load_config(args.config)
    errors, warnings = validate(cfg)
    for w in warnings:
        warn(w)
    for e in errors:
        bad(e)
    if not errors:
        ok("config.json תקין ומוכן ל-push.")
    return 1 if (errors or problems) else 0


def cmd_profiles(api, args):
    resp = api.call("GET", "/profiles")
    for p in items(resp, "profiles", "data"):
        say("  %s  %s" % (rid(p), p.get("name", "")))
    if resp is not None and not items(resp, "profiles", "data"):
        say("  אין פרופילים. צור אחד בדשבורד של Zernio.")


def cmd_accounts(api, args):
    resp = api.call("GET", "/accounts", query={"platform": "instagram"})
    rows = items(resp, "accounts")
    if resp is None:
        return
    if not rows:
        say("  אין חשבון אינסטגרם מחובר. חבר דרך הדשבורד של Zernio או הרץ `connect --profile <ID>`.")
        return
    for a in rows:
        flag = "" if a.get("isActive", True) and not a.get("needsReconnection") else "  <- צריך חיבור מחדש"
        say("  account_id=%s  profile_id=%s  @%s%s" % (rid(a), a.get("profileId", ""), a.get("username", "?"), flag))


def cmd_connect(api, args):
    resp = api.call("GET", "/connect/instagram", query={"profileId": args.profile})
    if resp:
        say("פתח את הקישור הזה בדפדפן והתחבר בעצמך לאינסטגרם:\n  " + resp.get("authUrl", json.dumps(resp, ensure_ascii=False)))


def fetch_posts(api, account):
    resp = api.call("GET", "/accounts/%s/posts" % urllib.parse.quote(account))
    return items(resp, "posts")


def cmd_posts(api, args):
    for p in fetch_posts(api, args.account):
        cap = (p.get("message") or "").replace("\n", " ")[:60]
        say("  %s  %s  %s  | %s" % (p.get("id", ""), (p.get("createdTime") or "")[:10], p.get("permalink", ""), cap))


def shortcode(url):
    m = re.search(r"instagram\.com/(?:[^/]+/)?(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)", url or "")
    return m.group(1) if m else None


def cmd_find_post(api, args):
    cfg = load_config(args.config) if os.path.exists(args.config) else {}
    account = args.account or g(cfg, "zernio.account_id")
    if not account:
        raise Stop("צריך account_id: ב-config.json או עם --account.")
    code = shortcode(args.url)
    if not code:
        raise Stop("זה לא נראה כמו קישור לפוסט/ריל באינסטגרם.")
    posts = fetch_posts(api, account)
    if posts is None or api.dry_run:
        return
    for p in posts:
        if shortcode(p.get("permalink", "")) == code:
            say("נמצא: platform_post_id = %s" % p.get("id"))
            say("  " + (p.get("message") or "")[:80].replace("\n", " "))
            return
    raise Stop("לא מצאתי את הפוסט בין 25 האחרונים. אם הוא ישן יותר - קח את ה-ID מהדשבורד של Zernio.")


def cmd_plan(args):
    cfg = load_config(args.config)
    errors, warnings = validate(cfg)
    payload = build_payload(cfg)
    say("זה מה שיישלח ל-Zernio:")
    say(json.dumps(payload, ensure_ascii=False, indent=2))
    say("")
    for w in warnings:
        warn(w)
    for e in errors:
        bad(e)
    if errors:
        say("\nיש %d בעיות לתקן לפני push." % len(errors))
        return 1
    say("\nתקין. כדי להעלות לאוויר:  python3 scripts/autopilot.py push --confirm %s" % CONFIRM_WORD)
    return 0


def find_existing(api, cfg):
    """Same name on the same account, or any active automation on the same post."""
    resp = api.call("GET", "/comment-automations", query={"profileId": g(cfg, "zernio.profile_id")})
    rows = items(resp, "automations")
    name = g(cfg, "rule_name")
    account = g(cfg, "zernio.account_id")
    post = None if g(cfg, "post.account_wide", False) else g(cfg, "post.platform_post_id")
    by_name = [a for a in rows if a.get("name") == name and a.get("accountId", account) == account]
    if by_name:
        return by_name[0], "name"
    if post:
        same_post = [a for a in rows if a.get("platformPostId") == post and a.get("isActive")]
        if same_post:
            return same_post[0], "post"
    return None, None


def require_confirm(args, action):
    if args.confirm != CONFIRM_WORD:
        raise Stop(
            "עצרתי. %s זו פעולה חיה באינסטגרם.\n"
            "  היא תרוץ רק עם אישור מפורש:  --confirm %s\n"
            "  (קלוד: אל תוסיף את זה לפני שהמשתמש כתב 'כן' בצ'אט.)" % (action, CONFIRM_WORD)
        )


def cmd_push(api, args):
    cfg = load_config(args.config)
    errors, warnings = validate(cfg)
    for w in warnings:
        warn(w)
    if errors:
        for e in errors:
            bad(e)
        raise Stop("לא מעלה - יש %d בעיות ב-config.json (הרץ plan)." % len(errors))
    if not api.dry_run:
        require_confirm(args, "יצירה/עדכון של אוטומציה")
    payload = build_payload(cfg)
    existing, why = (None, None) if api.dry_run else find_existing(api, cfg)

    if existing and why == "post" and existing.get("name") != g(cfg, "rule_name"):
        raise Stop(
            "על הפוסט הזה כבר רצה אוטומציה אחרת: '%s' (%s).\n"
            "  מטא מאפשרת רק אחת פעילה לכל פוסט. אפשרויות:\n"
            "  1) לשנות את rule_name ב-config לשם שלה ולהריץ push שוב (יעדכן אותה)\n"
            "  2) pause %s ואז push" % (existing.get("name"), rid(existing), rid(existing))
        )

    if existing:
        patch = {k: v for k, v in payload.items() if k not in ("profileId", "accountId", "platformPostId", "postTitle", "trigger")}
        # Clear optional fields the user removed from config, so updates are true replacements.
        patch.setdefault("buttons", [])
        patch.setdefault("dmMessageVariations", [])
        patch.setdefault("commentReplyVariations", [])
        patch.setdefault("excludeKeywords", [])
        if "commentReply" not in patch and existing.get("commentReply"):
            # The docs don't say how to clear a public reply, so we don't guess.
            warn("באוטומציה הקיימת יש תגובה ציבורית, וב-config אין. היא תישאר - לכבות אותה דרך הדשבורד של Zernio.")
        if "dmDelaySeconds" not in patch:
            patch["dmDelaySeconds"] = 0
        patch["isActive"] = True
        say("קיימת כבר אוטומציה בשם הזה (%s) - מעדכן במקום ליצור כפולה." % rid(existing))
        resp = api.call("PATCH", "/comment-automations/%s" % rid(existing), body=patch, write=True)
        auto = (resp or {}).get("automation", {})
        ok("עודכן. id=%s" % (rid(auto) or rid(existing)))
    else:
        if api.dry_run:
            say("(dry-run: בבדיקה אמיתית קודם בודקים אם קיימת אוטומציה באותו שם ומעדכנים אותה)")
        resp = api.call("POST", "/comment-automations", body=payload, write=True)
        if resp is None:
            return 0
        auto = resp.get("automation", {})
        ok("האוטומציה באוויר. id=%s" % rid(auto))
    if not api.dry_run:
        say("\nעכשיו בדיקה אמיתית:  python3 scripts/autopilot.py checklist")
    return 0


def cmd_rules(api, args):
    cfg = load_config(args.config) if os.path.exists(args.config) else {}
    resp = api.call("GET", "/comment-automations", query={"profileId": args.profile or g(cfg, "zernio.profile_id")})
    rows = items(resp, "automations")
    if resp is None:
        return
    if not rows:
        say("  אין אוטומציות.")
        return
    for a in rows:
        st = a.get("stats") or {}
        state = "פעיל" if a.get("isActive") else "מושהה"
        scope = a.get("platformPostId") or "כל החשבון"
        say("  %s  [%s]  %s" % (rid(a), state, a.get("name", "")))
        say("      מילים: %s (%s) | פוסט: %s | הופעל %s · נשלח %s · נכשל %s · קליקים %s" % (
            ", ".join(a.get("keywords") or []) or "(כל תגובה!)", a.get("matchMode", "?"), scope,
            st.get("triggered", st.get("totalTriggered", 0)), st.get("dmsSent", st.get("totalSent", 0)),
            st.get("dmsFailed", st.get("totalFailed", 0)), st.get("linkClicks", "-")))


def cmd_show(api, args):
    resp = api.call("GET", "/comment-automations/%s" % args.id)
    if resp is not None:
        say(json.dumps(resp, ensure_ascii=False, indent=2))


def cmd_logs(api, args):
    resp = api.call("GET", "/comment-automations/%s/logs" % args.id)
    if resp is None:
        return
    rows = items(resp, "logs", "data", "items")
    if not rows:
        say(json.dumps(resp, ensure_ascii=False, indent=2))
        return
    for r in rows[:50]:
        who = r.get("commenterUsername") or (r.get("commenter") or {}).get("username") or r.get("username") or "?"
        text = (r.get("commentText") or r.get("text") or "")[:50]
        say("  %s  @%s  [%s]  %s" % ((r.get("createdAt") or "")[:16], who, r.get("status", "?"), text))


def cmd_toggle(api, args, active):
    if not api.dry_run:
        require_confirm(args, "הפעלה" if active else "השהיה")
    api.call("PATCH", "/comment-automations/%s" % args.id, body={"isActive": active}, write=True)
    if not api.dry_run:
        ok("האוטומציה %s." % ("פעילה" if active else "מושהית"))


def cmd_remove(api, args):
    if not api.dry_run:
        require_confirm(args, "מחיקת אוטומציה (כולל כל הלוגים שלה)")
    api.call("DELETE", "/comment-automations/%s" % args.id, write=True)
    if not api.dry_run:
        ok("נמחקה.")


CHECKLIST = """
בדיקה חיה - 10 דקות, לפני שמפרסמים את הסטורי/הריל:

  [ ] 1. `rules` מראה את החוק כ"פעיל", עם הפוסט הנכון ומילת המפתח הנכונה.
  [ ] 2. מחשבון אינסטגרם אחר (לא החשבון שלך!) - כתוב תגובה עם מילת המפתח בדיוק.
  [ ] 3. תוך דקה אמורה להגיע הודעה בפרטי. אם החשבון השני לא עוקב אחריך -
         חפש אותה בתיקיית "בקשות הודעה", לא בתיבה הראשית.
  [ ] 4. לחץ על הכפתור - עמוד המסירה נפתח? הכפתור בעמוד מוריד / פותח את הדבר הנכון?
  [ ] 5. בדוק בטלפון, לא רק במחשב. העמוד קריא? הסרטון (אם יש) מתנגן?
  [ ] 6. תגובה בלי מילת המפתח (למשל "וואו") - לא אמורה לקבל כלום.
  [ ] 7. אם יש שער עוקבים: מחשבון שלא עוקב - מגיעה בקשה לעקוב? אחרי מעקב + לחיצה - מגיע הקישור?
  [ ] 8. `logs <ID>` מראה את התגובות שלך עם status שנשלח.
  [ ] 9. מחק את תגובות הבדיקה מהפוסט (או השאר - לא מזיק).

לא הגיע כלום?
  - חכה 2 דקות ונסה שוב, ותבדוק "בקשות הודעה".
  - `logs <ID>`: אם אין שם כלום - Zernio לא קיבל את התגובה (בדוק שהחשבון מחובר: `accounts`).
  - אם יש שם שורה עם כישלון - ההודעה שם מסבירה למה (למשל: הגדרות הודעות של החשבון השני).
  - ודא בהגדרות אינסטגרם: Settings -> Messages and story replies -> Connected tools ->
    "Allow access to messages" דלוק.
"""


def cmd_checklist(args):
    say(CHECKLIST)


# ---------------------------------------------------------------- main

def main(argv=None):
    p = argparse.ArgumentParser(prog="autopilot.py", description="dm-autopilot - Instagram keyword comments -> auto DM via Zernio")
    p.add_argument("--config", default=DEFAULT_CONFIG)
    p.add_argument("--dry-run", action="store_true", help="print requests, send nothing")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("doctor")
    sub.add_parser("profiles")
    sub.add_parser("accounts")
    c = sub.add_parser("connect"); c.add_argument("--profile", required=True)
    c = sub.add_parser("posts"); c.add_argument("--account", required=True)
    c = sub.add_parser("find-post"); c.add_argument("url"); c.add_argument("--account")
    sub.add_parser("plan")
    c = sub.add_parser("push"); c.add_argument("--confirm", default="")
    c = sub.add_parser("rules"); c.add_argument("--profile")
    c = sub.add_parser("show"); c.add_argument("id")
    c = sub.add_parser("logs"); c.add_argument("id")
    c = sub.add_parser("pause"); c.add_argument("id"); c.add_argument("--confirm", default="")
    c = sub.add_parser("resume"); c.add_argument("id"); c.add_argument("--confirm", default="")
    c = sub.add_parser("remove"); c.add_argument("id"); c.add_argument("--confirm", default="")
    sub.add_parser("checklist")

    args = p.parse_args(argv)
    if os.environ.get("DM_AUTOPILOT_DRY_RUN") == "1":
        args.dry_run = True
    try:
        if args.cmd == "doctor":
            return cmd_doctor(args)
        if args.cmd == "plan":
            return cmd_plan(args)
        if args.cmd == "checklist":
            return cmd_checklist(args) or 0
        key, base = api_settings(args.dry_run)
        api = Api(key, base, args.dry_run)
        handlers = {
            "profiles": cmd_profiles, "accounts": cmd_accounts, "connect": cmd_connect,
            "posts": cmd_posts, "find-post": cmd_find_post, "push": cmd_push, "rules": cmd_rules,
            "show": cmd_show, "logs": cmd_logs, "remove": cmd_remove,
        }
        if args.cmd == "pause":
            return cmd_toggle(api, args, False) or 0
        if args.cmd == "resume":
            return cmd_toggle(api, args, True) or 0
        return handlers[args.cmd](api, args) or 0
    except Stop as exc:
        print("\n" + str(exc), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
