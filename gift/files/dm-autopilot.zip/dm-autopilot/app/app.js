// האוטומציות שלי — native-feeling dashboard over Zernio. Vanilla JS, hash routes:
//   #/home  #/automations  #/contacts  #/settings
//   #/new/comment  #/new/story   #/a/<id>   #/a/<id>/edit

// שם הבעלים לברכה בדף הבית — מגיע מ-<meta name="owner-name"> ב-index.html (ריק = בלי שם)
const OWNER = (document.querySelector('meta[name="owner-name"]')?.content || "").trim();
const app = document.getElementById("app");
const toastEl = document.getElementById("toast");
const cache = { account: null, posts: null, authed: null };
const desktop = () => matchMedia("(min-width: 900px)").matches;

// ------------------------------------------------------------------ utils

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmtDay = (iso) =>
  iso ? new Intl.DateTimeFormat("he-IL", { day: "numeric", month: "numeric", timeZone: "Asia/Jerusalem" }).format(new Date(iso)) : "";
// Natural Hebrew ("לפני שעתיים", "שלשום") — Intl's Hebrew adds "(2)" to dual forms.
function ago(iso) {
  if (!iso) return "";
  const sec = (Date.now() - new Date(iso)) / 1000;
  if (sec < 60) return "עכשיו";
  const n = (v, one, two, many) => (v === 1 ? one : v === 2 ? two : `${v} ${many}`);
  const m = Math.round(sec / 60);
  if (m < 60) return `לפני ${n(m, "דקה", "2 דקות", "דקות")}`;
  const h = Math.round(sec / 3600);
  if (h < 24) return `לפני ${n(h, "שעה", "שעתיים", "שעות")}`;
  const d = Math.round(sec / 86400);
  if (d === 1) return "אתמול";
  if (d === 2) return "שלשום";
  if (d < 7) return `לפני ${d} ימים`;
  if (d < 30) return `לפני ${n(Math.round(d / 7), "שבוע", "שבועיים", "שבועות")}`;
  if (d < 365) return `לפני ${n(Math.round(d / 30), "חודש", "חודשיים", "חודשים")}`;
  return `לפני ${n(Math.round(d / 365), "שנה", "שנתיים", "שנים")}`;
}
const AVATAR_COLORS = ["#0a84ff", "#5e5ce6", "#bf5af2", "#ff375f", "#ff9f0a", "#30b0c7", "#34c759", "#ff6482"];
function avatarColor(name) {
  let h = 0;
  for (const ch of String(name || "")) h = (h * 31 + ch.codePointAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
const initial = (name) => esc((String(name || "?").trim().charAt(0) || "?").toUpperCase());

function toast(msg, bad = false) {
  toastEl.textContent = msg;
  toastEl.className = "show" + (bad ? " bad" : "");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => (toastEl.className = bad ? "bad" : ""), bad ? 5500 : 2400);
}

async function api(path, { method = "GET", body } = {}) {
  const r = await fetch("/api" + path, {
    method,
    headers: body !== undefined ? { "Content-Type": "application/json" } : {},
    body: body !== undefined ? JSON.stringify(body) : undefined,
    credentials: "same-origin",
  });
  const data = await r.json().catch(() => ({}));
  if (r.status === 401 && path !== "/login") {
    cache.authed = false;
    renderLogin();
    throw new Error("צריך להתחבר מחדש");
  }
  if (!r.ok) throw new Error(data.error || "משהו השתבש");
  return data;
}

async function getPosts(force = false) {
  if (!cache.posts || force) cache.posts = (await api("/posts")).posts;
  return cache.posts;
}

// ------------------------------------------------------------------ icons

const svg = (d, size = 22, sw = 1.9) =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const P = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  contacts: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M16.5 14.3c2.9.3 5 2.3 5 5.7"/>',
  automations: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  back: '<path d="m9 5 7 7-7 7"/>',
  chev: '<path d="m15 6-6 6 6 6"/>',
  more: '<circle cx="5" cy="12" r="1.3" fill="currentColor"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><circle cx="19" cy="12" r="1.3" fill="currentColor"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
  eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  refresh: '<path d="M21 12a9 9 0 1 1-2.6-6.4L21 8"/><path d="M21 3v5h-5"/>',
  chat: '<path d="M21 11.5a8.4 8.4 0 0 1-12.4 7.4L3 21l2.1-5.4A8.5 8.5 0 1 1 21 11.5z"/>',
  story: '<circle cx="12" cy="12" r="9" stroke-dasharray="3 2.6"/><path d="M12 8v8M8 12h8"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  cloud: '<path d="M7 18a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 8.5 4.5 4.5 0 0 1 17.5 18z"/>',
  pin: '<path d="M12 2a7 7 0 0 1 7 7c0 5-7 13-7 13S5 14 5 9a7 7 0 0 1 7-7z"/><circle cx="12" cy="9" r="2.5"/>',
  reply: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 6 6v5"/>',
  shield: '<path d="M12 2 4 5v6c0 5 3.4 9.3 8 11 4.6-1.7 8-6 8-11V5z"/><path d="m9 12 2 2 4-4"/>',
  heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21.2l8.8-8.8a5.5 5.5 0 0 0 0-7.8z"/>',
  faceid: '<path d="M7 3H5a2 2 0 0 0-2 2v2M17 3h2a2 2 0 0 1 2 2v2M7 21H5a2 2 0 0 1-2-2v-2M17 21h2a2 2 0 0 0 2-2v-2"/><path d="M9 9v1M15 9v1M12 9v4h-1M9 16c1.7 1.3 4.3 1.3 6 0"/>',
  finger: '<path d="M12 11v2a8 8 0 0 1-2 5.3"/><path d="M8 11a4 4 0 0 1 8 0v1a12 12 0 0 1-1 4.7"/><path d="M5 12v-1a7 7 0 0 1 12.6-4.2"/><path d="M19 11v1c0 1.4-.2 2.8-.5 4"/>',
};
const ic = (name, size = 22, sw) => svg(P[name], size, sw);
const igmini = `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/></svg>`;

// --------------------------------------------------------------- passkeys
// Face ID / Touch ID. The device keeps a signed ticket from the server (see
// api/passkey.js); the fingerprint or face never leaves the device.

const PK_KEY = "adm_passkey";
const PK_SKIP = "adm_passkey_skip";
const store = {
  get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
  set: (k, v) => { try { localStorage.setItem(k, v); } catch {} },
  del: (k) => { try { localStorage.removeItem(k); } catch {} },
};
const b64u = {
  enc: (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""),
  dec: (s) => Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4)), (c) => c.charCodeAt(0)),
};
const isIOS = () => /iPhone|iPad/.test(navigator.userAgent) || (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1);
const bioName = () => (isIOS() ? "Face ID" : /Windows/.test(navigator.userAgent) ? "Windows Hello" : "טביעת אצבע");
function deviceName() {
  const ua = navigator.userAgent;
  if (/iPhone/.test(ua)) return "iPhone";
  if (isIOS()) return "iPad";
  if (/Macintosh/.test(ua)) return "Mac";
  if (/Android/.test(ua)) return "Android";
  if (/Windows/.test(ua)) return "Windows";
  return "מכשיר";
}
async function bioAvailable() {
  try {
    return !!window.PublicKeyCredential && (await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable());
  } catch {
    return false;
  }
}
const bioIcon = (size = 22) => ic(isIOS() ? "faceid" : "finger", size);

async function enableBio() {
  const { options: o } = await api("/passkey", {
    method: "POST",
    body: { action: "register-options", ticket: store.get(PK_KEY), device: deviceName() },
  });
  const cred = await navigator.credentials.create({
    publicKey: {
      ...o,
      challenge: b64u.dec(o.challenge),
      user: { ...o.user, id: b64u.dec(o.user.id) },
      excludeCredentials: (o.excludeCredentials || []).map((c) => ({ ...c, id: b64u.dec(c.id) })),
    },
  });
  const { ticket } = await api("/passkey", {
    method: "POST",
    body: {
      action: "register-verify",
      device: deviceName(),
      credential: {
        id: cred.id,
        rawId: b64u.enc(cred.rawId),
        type: cred.type,
        response: {
          clientDataJSON: b64u.enc(cred.response.clientDataJSON),
          attestationObject: b64u.enc(cred.response.attestationObject),
          transports: cred.response.getTransports?.() || [],
        },
        clientExtensionResults: cred.getClientExtensionResults?.() || {},
        authenticatorAttachment: cred.authenticatorAttachment || undefined,
      },
    },
  });
  store.set(PK_KEY, ticket);
}

async function loginBio() {
  const ticket = store.get(PK_KEY);
  const { options: o } = await api("/passkey", { method: "POST", body: { action: "login-options", ticket } });
  const cred = await navigator.credentials.get({
    publicKey: {
      ...o,
      challenge: b64u.dec(o.challenge),
      allowCredentials: (o.allowCredentials || []).map((c) => ({ ...c, id: b64u.dec(c.id) })),
    },
  });
  const r = await api("/passkey", {
    method: "POST",
    body: {
      action: "login-verify",
      ticket,
      credential: {
        id: cred.id,
        rawId: b64u.enc(cred.rawId),
        type: cred.type,
        response: {
          clientDataJSON: b64u.enc(cred.response.clientDataJSON),
          authenticatorData: b64u.enc(cred.response.authenticatorData),
          signature: b64u.enc(cred.response.signature),
          ...(cred.response.userHandle ? { userHandle: b64u.enc(cred.response.userHandle) } : {}),
        },
        clientExtensionResults: cred.getClientExtensionResults?.() || {},
        authenticatorAttachment: cred.authenticatorAttachment || undefined,
      },
    },
  });
  store.set(PK_KEY, r.ticket);
}

function bioError(e) {
  if (e?.name === "NotAllowedError") return "הזיהוי בוטל או שפג הזמן. נסו שוב.";
  if (e?.name === "InvalidStateError") return `${bioName()} כבר פעיל במכשיר הזה.`;
  return e?.message || "הזיהוי נכשל";
}

// Offered once per device, right after a password login.
async function offerBio() {
  if (store.get(PK_KEY) || store.get(PK_SKIP) || !(await bioAvailable())) return;
  const sh = openSheet({
    title: "",
    cancel: "",
    body: `<div class="bio-offer">
      <div class="bio-mark">${bioIcon(38)}</div>
      <h3>להיכנס בפעם הבאה עם ${bioName()}?</h3>
      <p>במקום להקליד סיסמה. הסיסמה נשארת כגיבוי.</p>
      <div id="bioerr"></div>
      <button class="btn primary block" id="bioyes">הפעלה</button>
      <button class="btn block" id="biono">לא עכשיו</button>
    </div>`,
  });
  sh.el.querySelector("#biono").onclick = () => {
    store.set(PK_SKIP, "1");
    sh.close();
  };
  sh.el.querySelector("#bioyes").onclick = async (e) => {
    e.currentTarget.disabled = true;
    try {
      await enableBio();
      sh.close();
      toast(`${bioName()} הופעל ✓`);
    } catch (err) {
      sh.el.querySelector("#bioerr").innerHTML = `<div class="alert bad">${esc(bioError(err))}</div>`;
      sh.el.querySelector("#bioyes").disabled = false;
    }
  };
}

// ----------------------------------------------------------------- sheets
// Bottom sheet on phones (drag down to dismiss), centred dialog on desktop.

function closeSheets() {
  document.querySelectorAll(".sheet-wrap").forEach((w) => w._close?.(true) ?? w.remove());
}

function openSheet({ title = "", body = "", tall = false, cancel = "סגירה", onClose } = {}) {
  closeSheets();
  const w = document.createElement("div");
  w.className = "sheet-wrap";
  w.innerHTML = `<div class="sheet-bg"></div>
    <div class="sheet ${tall ? "tall" : ""}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="grab"></div>
      <div class="sheet-hd"><span></span><h3>${esc(title)}</h3>${
        cancel ? `<button class="hdr-btn x" data-close>${esc(cancel)}</button>` : `<span></span>`
      }</div>
      <div class="sheet-bd">${body}</div>
    </div>`;
  document.body.append(w);
  requestAnimationFrame(() => requestAnimationFrame(() => w.classList.add("open")));
  const sheet = w.querySelector(".sheet");
  let closed = false;
  const onKey = (e) => e.key === "Escape" && close();
  function close(instant = false) {
    if (closed) return;
    closed = true;
    document.removeEventListener("keydown", onKey);
    w.classList.remove("open");
    instant ? w.remove() : setTimeout(() => w.remove(), 340);
    onClose?.();
  }
  w._close = close;
  document.addEventListener("keydown", onKey);
  w.querySelector(".sheet-bg").onclick = () => close();
  w.querySelector("[data-close]")?.addEventListener("click", () => close());

  let y0 = null;
  let dy = 0;
  for (const h of [w.querySelector(".grab"), w.querySelector(".sheet-hd")]) {
    h.addEventListener("touchstart", (e) => {
      y0 = e.touches[0].clientY;
      dy = 0;
      sheet.style.transition = "none";
    }, { passive: true });
  }
  w.addEventListener("touchmove", (e) => {
    if (y0 == null) return;
    dy = Math.max(0, e.touches[0].clientY - y0);
    sheet.style.transform = `translateY(${dy}px)`;
  }, { passive: true });
  w.addEventListener("touchend", () => {
    if (y0 == null) return;
    y0 = null;
    sheet.style.transition = "";
    sheet.style.transform = "";
    if (dy > 110) close();
  });
  return { el: w.querySelector(".sheet-bd"), close };
}

// iOS action sheet: a list of choices plus a separate cancel.
function actionSheet(title, actions) {
  closeSheets();
  const w = document.createElement("div");
  w.className = "sheet-wrap";
  w.innerHTML = `<div class="sheet-bg"></div>
    <div class="sheet actions-sheet" role="dialog" aria-modal="true">
      <div class="grp">${title ? `<div class="ttl">${esc(title)}</div>` : ""}${actions
        .map((a, i) => `<button data-i="${i}" class="${a.danger ? "danger" : ""}">${esc(a.label)}</button>`)
        .join("")}</div>
      <div class="grp"><button class="cancel" data-close>ביטול</button></div>
    </div>`;
  document.body.append(w);
  requestAnimationFrame(() => requestAnimationFrame(() => w.classList.add("open")));
  const close = () => {
    w.classList.remove("open");
    document.removeEventListener("keydown", onKey);
    setTimeout(() => w.remove(), 340);
  };
  const onKey = (e) => e.key === "Escape" && close();
  w._close = (instant) => (instant ? w.remove() : close());
  document.addEventListener("keydown", onKey);
  w.onclick = (e) => {
    const b = e.target.closest("[data-i]");
    if (b) {
      close();
      actions[+b.dataset.i].run();
    } else if (e.target.closest("[data-close]") || e.target.classList.contains("sheet-bg")) close();
  };
}

// ------------------------------------------------------------------ shell

const NAV = [
  ["home", "#/home", "בית"],
  ["automations", "#/automations", "אוטומציות"],
  ["contacts", "#/contacts", "אנשי קשר"],
  ["settings", "#/settings", "הגדרות"],
];
let firstPaint = null;
let ptrAbort = null;

function frame(active, html, { editing = false } = {}) {
  const acc = cache.account;
  ptrAbort?.abort();
  document.body.classList.toggle("editing", editing);
  app.innerHTML = `
    <div class="shell">
      <aside class="sidebar" aria-label="ניווט">
        <a class="brand" href="#/home"><img src="/icon-192.png" alt=""><span>האוטומציות שלי</span></a>
        <button class="btn primary side-new" data-new>${ic("plus", 18, 2.2)} אוטומציה חדשה</button>
        ${NAV.map(
          ([id, href, label]) =>
            `<a class="side-item ${active === id ? "active" : ""}" href="${href}" ${active === id ? 'aria-current="page"' : ""}>${ic(id, 20)}<span>${label}</span></a>`,
        ).join("")}
        <a class="side-foot" href="#/settings">${
          acc?.picture ? `<img src="${esc(acc.picture)}" alt="" referrerpolicy="no-referrer">` : `<span class="avatar" style="width:34px;height:34px;background:${avatarColor(acc?.username)}">${initial(acc?.username)}</span>`
        }<div style="min-width:0"><div style="font-weight:600;font-size:14px" dir="ltr">${acc ? "@" + esc(acc.username) : ""}</div><div class="s"><i></i>אינסטגרם מחובר</div></div></a>
      </aside>
      <div class="main">${html}</div>
    </div>
    <nav class="tabbar" aria-label="ניווט">${NAV.map(
      ([id, href, label]) =>
        `<a class="tab-item ${active === id ? "active" : ""}" href="${href}" ${active === id ? 'aria-current="page"' : ""}>${ic(id, 25, active === id ? 2.2 : 1.8)}<span>${label}</span></a>`,
    ).join("")}</nav>`;
  app.querySelectorAll("[data-new]").forEach((b) => (b.onclick = openNewChooser));
  wireHeader();
  const done = firstPaint;
  firstPaint = null;
  done?.();
  return app.querySelector(".main");
}

function hdr({ title = "", back, start = "", end = "", top = false, solid = false } = {}) {
  return `<header class="hdr ${top ? "top" : "always"} ${solid ? "solid" : ""}"><div class="hdr-row">
    <div class="hdr-start">${back ? `<a class="hdr-back" href="${back.href}">${ic("back", 22, 2.3)}<span>${esc(back.label)}</span></a>` : start}</div>
    <div class="hdr-title">${esc(title)}</div>
    <div class="hdr-end">${end}</div>
  </div></header>`;
}

function wireHeader() {
  const h = app.querySelector(".hdr");
  window.removeEventListener("scroll", wireHeader.f);
  if (!h) return;
  wireHeader.f = () => h.classList.toggle("scrolled", window.scrollY > 28);
  wireHeader.f();
  window.addEventListener("scroll", wireHeader.f, { passive: true });
}

const loading = (active, title = "") =>
  frame(
    active,
    `${hdr({ title, top: true })}<div class="page">
      ${title ? `<h1 class="large-title">${esc(title)}</h1>` : `<div class="sk" style="width:45%;height:34px;margin:8px 4px 18px"></div>`}
      <div class="sk sk-block"></div><div class="sk sk-block"></div><div class="sk sk-block" style="height:160px"></div>
    </div>`,
  );

// Pull to refresh (touch screens, top of page).
function enablePTR(reload) {
  if (desktop() || !("ontouchstart" in window)) return;
  ptrAbort = new AbortController();
  const opt = { signal: ptrAbort.signal, passive: true };
  const ind = document.createElement("div");
  ind.className = "ptr";
  ind.innerHTML = ic("refresh", 18, 2.2);
  app.append(ind);
  let y0 = null;
  let dy = 0;
  window.addEventListener("touchstart", (e) => {
    y0 = window.scrollY <= 0 && !document.querySelector(".sheet-wrap") ? e.touches[0].clientY : null;
    dy = 0;
  }, opt);
  window.addEventListener("touchmove", (e) => {
    if (y0 == null) return;
    dy = Math.max(0, e.touches[0].clientY - y0);
    ind.style.opacity = Math.min(dy / 80, 1);
    ind.style.transform = `translateY(${Math.min(dy, 120) * 0.55 - 40}px) rotate(${dy * 3}deg)`;
  }, opt);
  window.addEventListener("touchend", async () => {
    if (y0 == null) return;
    y0 = null;
    if (dy > 80) {
      ind.classList.add("spin");
      ind.style.transform = "translateY(22px)";
      await reload();
    }
    ind.style.opacity = 0;
    ind.style.transform = "translateY(-40px)";
  }, opt);
}

// ------------------------------------------------------------ shared bits

const STATUS = {
  sent: ["נשלח", "on"],
  gated: ["ממתין ל\"עקבתי\"", "wait"],
  pending: ["בתור", "wait"],
  skipped: ["לא נשלח", "off"],
  failed: ["נכשל", "bad"],
};
const AUDIENCE = {
  passed: "עוקב",
  blocked: "לא עוקב",
  gate_sent: "נשלחה בקשת מעקב",
  gate_passed: "אישר מעקב",
  gate_failed: "לחץ אבל לא עוקב",
};
const MATCH = {
  contains: ["מכיל", "התגובה מכילה את המילה, גם בתוך משפט (\"אני רוצה מדריך!\")."],
  word: ["מילה שלמה", "המילה מופיעה כמילה נפרדת בתגובה."],
  exact: ["בדיוק", "כל התגובה היא בדיוק המילה, בלי שום דבר נוסף."],
};
const LIMITS = { gmsg: 640, gbtn: 20, gno: 640, dm: 640, btn: 20 };
const C = { blue: "var(--accent)", green: "var(--green)", red: "var(--red)", orange: "var(--orange)", purple: "var(--purple)" };

const statusPill = (active) => `<span class="pill ${active ? "on" : "off"}">${active ? "פעילה" : "מושהית"}</span>`;
const kwList = (a) => a.keywords.map((k) => `"${esc(k)}"`).join(", ");
function triggerText(a) {
  const gate = a.followGate?.enabled ? " · לעוקבים" : "";
  if (a.trigger === "story_reply")
    return `תגובה ל${a.platformPostId ? "סטורי מסוים" : "כל סטורי"} · ${a.anyReply ? "כל תגובה" : kwList(a)}${gate}`;
  return `תגובה עם ${kwList(a)} על פוסט${gate}`;
}
function leadThumb(a, picture, cls = "") {
  if (a.trigger === "story_reply") return `<div class="thumb story ${cls}"><div>${ic("story", 22)}</div></div>`;
  return picture
    ? `<img class="thumb ${cls}" src="${esc(picture)}" alt="" loading="lazy" referrerpolicy="no-referrer">`
    : `<div class="thumb ${cls}">${ic("image", 20)}</div>`;
}

// Counts per day for the last 7 days, oldest first.
function days7(items, pred = () => true) {
  const out = Array(7).fill(0);
  const now = Date.now();
  for (const i of items) {
    if (!pred(i)) continue;
    const d = Math.floor((now - new Date(i.at)) / 864e5);
    if (d >= 0 && d < 7) out[6 - d]++;
  }
  return out;
}
const spark = (arr, color) => {
  const max = Math.max(1, ...arr);
  return `<div class="spark" dir="ltr">${arr
    .map((v) => `<span class="${v ? "hot" : ""}" style="height:${Math.max(12, (v / max) * 100)}%;--c:${color}"></span>`)
    .join("")}</div>`;
};
const tile = (label, value, color, arr) =>
  `<div class="tile"><div class="l"><i style="background:${color}"></i>${label}</div><div class="v">${value}</div>${arr ? spark(arr, color) : ""}</div>`;

function logItem(l, showAuto = false) {
  const [label, cls] = STATUS[l.status] || [l.status || "—", "off"];
  const src = l.source === "dm" ? " · מהודעה" : l.source === "story_reply" ? " · מסטורי" : "";
  return `<div class="item">
    <span class="avatar" style="background:${avatarColor(l.who)}">${initial(l.who)}</span>
    <div class="body"><div class="title" dir="auto">${esc(l.who || "משתמש")}</div>
      <div class="sub">"${esc(l.text)}" · ${ago(l.at)}${showAuto && l.automationName ? ` · ${esc(l.automationName)}` : ""}${src}</div>
      ${l.error && l.status === "failed" ? `<div class="sub" style="color:var(--red)">${esc(l.error)}</div>` : ""}</div>
    <div class="trail"><span class="pill ${cls}">${esc(label)}</span>${l.audience ? `<span>${esc(AUDIENCE[l.audience] || l.audience)}</span>` : ""}</div>
  </div>`;
}

const emptyState = (icon, title, text, cta = "") =>
  `<div class="empty"><div class="em-ic">${ic(icon, 30)}</div><h3>${title}</h3><p>${text}</p>${cta}</div>`;

function greeting() {
  const h = +new Intl.DateTimeFormat("en-GB", { hour: "numeric", hour12: false, timeZone: "Asia/Jerusalem" }).format(new Date());
  return h < 5 ? "לילה טוב" : h < 12 ? "בוקר טוב" : h < 17 ? "צהריים טובים" : h < 21 ? "ערב טוב" : "לילה טוב";
}

// ------------------------------------------------------------------ login

function renderLogin() {
  closeSheets();
  document.body.classList.remove("editing");
  ptrAbort?.abort();
  const bio = !!store.get(PK_KEY) && !!window.PublicKeyCredential;
  app.innerHTML = `
    <div class="login-wrap login">
      <div class="login-top">
        <img class="app-icon" src="/icon-512.png" alt="">
        <h1>האוטומציות שלי</h1>
        <div class="muted">תגובה בפוסט ← הודעה בפרטי, אוטומטית</div>
      </div>
      <form class="login-bottom" id="login">
        ${bio ? `<button type="button" class="btn primary block" id="bio">${bioIcon(22)} כניסה עם ${bioName()}</button><div class="or">או עם סיסמה</div>` : ""}
        <input class="in" dir="ltr" type="password" id="pw" autocomplete="current-password" placeholder="סיסמה" required aria-label="סיסמה">
        <div id="err"></div>
        <button class="btn ${bio ? "tinted" : "primary"} block" id="pwbtn">כניסה</button>
      </form>
    </div>`;
  const done = firstPaint;
  firstPaint = null;
  done?.();
  const form = document.getElementById("login");
  const err = (m) => (document.getElementById("err").innerHTML = `<div class="alert bad">${esc(m)}</div>`);
  if (!bio && desktop()) form.pw.focus();
  const bioBtn = document.getElementById("bio");
  bioBtn?.addEventListener("click", async () => {
    bioBtn.disabled = true;
    try {
      await loginBio();
      cache.authed = true;
      route();
    } catch (ex) {
      // A ticket the server no longer accepts can never work again on this device.
      if (/כבר לא תקף/.test(ex.message)) store.del(PK_KEY);
      err(bioError(ex));
      bioBtn.disabled = false;
    }
  });
  form.onsubmit = async (e) => {
    e.preventDefault();
    const btn = document.getElementById("pwbtn");
    btn.disabled = true;
    try {
      await api("/login", { method: "POST", body: { password: form.pw.value } });
      cache.authed = true;
      await route();
      offerBio();
    } catch (ex) {
      err(ex.message);
      btn.disabled = false;
    }
  };
}

// ------------------------------------------------------------------- home

async function renderHome() {
  loading("home");
  const [{ account, automations }, { items }] = await Promise.all([
    api("/automations"),
    api("/activity").catch(() => ({ items: [] })),
  ]);
  cache.account = account;
  const weekAgo = Date.now() - 7 * 864e5;
  const week = items.filter((i) => new Date(i.at) >= weekAgo);
  const firstSeen = new Map();
  for (const i of [...items].reverse()) {
    const k = i.commenterId || i.who;
    if (!firstSeen.has(k)) firstSeen.set(k, i);
  }
  const newcomers = [...firstSeen.values()];
  const live = automations.filter((a) => a.isActive).length;
  const today = new Intl.DateTimeFormat("he-IL", { weekday: "long", day: "numeric", month: "long", timeZone: "Asia/Jerusalem" }).format(new Date());

  const page = frame(
    "home",
    `${hdr({
      title: "בית",
      top: true,
      end: `<a href="#/settings" aria-label="הגדרות">${
        account?.picture ? `<img class="hdr-avatar" src="${esc(account.picture)}" alt="" referrerpolicy="no-referrer">` : ""
      }</a>`,
    })}
    <div class="page">
      <div class="kicker">${today}</div>
      <h1 class="large-title">${greeting()}${OWNER ? `, ${esc(OWNER)}` : ""}</h1>

      <div class="tiles">
        ${tile("הופעלו", week.length, C.blue, days7(items))}
        ${tile("נשלחו בפרטי", week.filter((i) => i.status === "sent").length, C.green, days7(items, (i) => i.status === "sent"))}
        ${tile("אנשי קשר חדשים", newcomers.filter((i) => new Date(i.at) >= weekAgo).length, C.purple, days7(newcomers))}
        ${tile("ממתינים ל\"עקבתי\"", week.filter((i) => i.status === "gated").length, C.orange, days7(items, (i) => i.status === "gated"))}
      </div>
      <p class="foot">7 הימים האחרונים</p>

      <div class="sec"><h2>התחילו כאן</h2></div>
      <div class="quick">
        <a class="qa" href="#/new/comment"><span class="tag-pop">פופולרי</span>
          <div class="ic" style="background:linear-gradient(135deg,#0a84ff,#5e5ce6)">${ic("chat", 21, 2)}</div>
          <div class="t">לינק אוטומטי מתגובות</div><div class="s">מגיבים מילה בפוסט, מקבלים לינק בפרטי</div></a>
        <a class="qa" href="#/new/story">
          <div class="ic" style="background:linear-gradient(45deg,#f9ce34,#ee2a7b,#6228d7)">${ic("story", 21, 2)}</div>
          <div class="t">לידים מסטוריז</div><div class="s">מגיבים לסטורי, מקבלים לינק בפרטי</div></a>
      </div>

      <div class="list" style="margin-top:12px">
        <a class="item" href="#/automations"><span class="item-icon" style="background:var(--accent)">${ic("automations", 18, 2.2)}</span>
          <div class="body"><div class="title">האוטומציות שלי</div></div>
          <span class="trail" style="font-size:15px">${live} פעילות מתוך ${automations.length}</span><span class="chev">${ic("chev", 18, 2.4)}</span></a>
      </div>

      <div class="sec"><h2>פעילות אחרונה</h2>${items.length ? `<a href="#/contacts">הכל</a>` : ""}</div>
      ${
        items.length
          ? `<div class="list with-avatars">${items.slice(0, 8).map((l) => logItem(l, true)).join("")}</div>`
          : `<div class="list">${emptyState("chat", "עוד אין פעילות", "ברגע שמישהו יגיב עם מילת מפתח, זה יופיע כאן.")}</div>`
      }
    </div>`,
  );
  enablePTR(() => route());
  return page;
}

// ------------------------------------------------------------ automations

async function renderAutomations() {
  loading("automations", "אוטומציות");
  const [{ account, automations }, posts] = await Promise.all([api("/automations"), getPosts().catch(() => [])]);
  cache.account = account;
  const pic = Object.fromEntries(posts.map((p) => [p.id, p.picture]));
  let filter = "";

  const page = frame(
    "automations",
    `${hdr({
      title: "אוטומציות",
      top: true,
      end: `<button class="hdr-icon hdr-new" data-new aria-label="אוטומציה חדשה">${ic("plus", 20, 2.4)}<span>אוטומציה חדשה</span></button>`,
    })}
    <div class="page">
      <h1 class="large-title">אוטומציות</h1>
      <div class="toolbar">
        <label class="search">${ic("search", 17)}<input id="q" type="search" placeholder="חיפוש" aria-label="חיפוש באוטומציות" autocomplete="off"></label>
        <div class="seg" id="flt"><button class="sel" data-f="">הכל</button><button data-f="on">פעילות</button><button data-f="off">מושהות</button></div>
      </div>
      <div id="rows"></div>
    </div>`,
  );
  page.querySelectorAll("[data-new]").forEach((b) => (b.onclick = openNewChooser));

  const draw = () => {
    const q = page.querySelector("#q").value.trim().toLowerCase();
    const shown = automations.filter(
      (a) =>
        (!filter || (filter === "on") === a.isActive) &&
        (!q || a.name.toLowerCase().includes(q) || a.keywords.some((k) => k.toLowerCase().includes(q))),
    );
    page.querySelector("#rows").innerHTML = shown.length
      ? `<div class="list with-thumbs">${shown
          .map(
            (a) => `<a class="item" href="#/a/${esc(a.id)}">
              ${leadThumb(a, pic[a.platformPostId])}
              <div class="body">
                <div class="title">${esc(a.name)}</div>
                <div class="sub">${triggerText(a)}</div>
                <div class="meta">${statusPill(a.isActive)}<span class="num">${a.stats.sent} נשלחו · ${a.stats.triggered} הופעלו</span></div>
              </div>
              <span class="chev">${ic("chev", 18, 2.4)}</span>
            </a>`,
          )
          .join("")}</div>`
      : automations.length
        ? `<div class="list">${emptyState("search", "לא נמצא", "אין אוטומציות שמתאימות לחיפוש.")}</div>`
        : `<div class="list">${emptyState(
            "automations",
            "עדיין אין אוטומציות",
            "בוחרים פוסט או סטורי, מילת מפתח והלינק ששולחים. זה לוקח דקה.",
            `<button class="btn primary" data-new2>${ic("plus", 18, 2.4)} אוטומציה חדשה</button>`,
          )}</div>`;
    page.querySelector("[data-new2]")?.addEventListener("click", openNewChooser);
  };
  page.querySelector("#q").addEventListener("input", draw);
  page.querySelectorAll("#flt button").forEach((b) => {
    b.onclick = () => {
      filter = b.dataset.f;
      page.querySelectorAll("#flt button").forEach((x) => x.classList.toggle("sel", x === b));
      draw();
    };
  });
  draw();
  enablePTR(() => route());
}

// "+ אוטומציה חדשה": בוחרים ממה האוטומציה מתחילה.
function openNewChooser() {
  openSheet({
    title: "אוטומציה חדשה",
    body: `<div class="chooser">
      <a class="qa" href="#/new/comment">
        <div class="ic" style="background:linear-gradient(135deg,#0a84ff,#5e5ce6)">${ic("chat", 21, 2)}</div>
        <div><div class="t">לינק אוטומטי מתגובות</div><div class="s">מישהו מגיב מילה על פוסט או ריל, ומקבל את הלינק בפרטי</div></div></a>
      <a class="qa" href="#/new/story">
        <div class="ic" style="background:linear-gradient(45deg,#f9ce34,#ee2a7b,#6228d7)">${ic("story", 21, 2)}</div>
        <div><div class="t">לידים מסטוריז</div><div class="s">מישהו מגיב לסטורי, ומקבל את הלינק בפרטי</div></div></a>
    </div>`,
  });
}

// ------------------------------------------------------------- automation

const DEFAULTS = {
  name: "",
  isActive: true,
  trigger: "comment",
  anyReply: false,
  heart: true,
  keywords: [],
  matchMode: "contains",
  commentReplies: ["אצלך בפרטי 📩", "שלחתי לך בפרטי!", "קיבלת?"],
  followGate: {
    enabled: true,
    message: "רוצים את זה? 🎁\nזה לעוקבים בלבד - עקבו אחריי ולחצו על הכפתור 👇",
    buttonLabel: "עקבתי! שלחו לי",
    notFollowingMessage: "נראה שעדיין לא עקבת 🙂\nעקבו אחריי ולחצו שוב על הכפתור - וזה אצלכם.",
  },
  dmMessage: "לחצו על הכפתור!",
  linkButtonTitle: "",
  linkUrl: "",
  stats: { triggered: 0, sent: 0, failed: 0 },
};

async function renderAutomation(id, mode, trig = "comment") {
  const creating = mode === "new";
  const editable = mode !== "view";
  loading("automations");
  const storyNew = creating && trig === "story_reply";
  const [detail, posts, list, stories] = await Promise.all([
    creating ? null : api(`/automations/${id}`),
    storyNew ? [] : getPosts(editable).catch(() => []),
    editable || !cache.account
      ? api("/automations").then((d) => {
          cache.account = d.account;
          return d.automations;
        })
      : null,
    storyNew ? api("/posts?kind=stories").then((d) => d.stories).catch(() => []) : [],
  ]);
  const a = detail?.automation || null;
  const s = structuredClone(a || { ...DEFAULTS, trigger: trig, name: trig === "story_reply" ? "תגובות לסטורי" : "" });
  const story = s.trigger === "story_reply";
  if (creating) s.platformPostId = null;
  let post = story ? null : posts.find((p) => p.id === s.platformPostId) || null;
  let storyPick = null; // the live story picked for a new "specific story" rule
  let scope = s.platformPostId ? "one" : "any";
  let active = a?.isActive ?? true;
  let dirty = false;
  const taken = new Map(
    (list || []).filter((x) => x.isActive && x.id !== id && x.trigger !== "story_reply").map((x) => [x.platformPostId, x.name]),
  );
  let pvTab = "dm";
  const back = creating ? "#/automations" : editable ? `#/a/${esc(id)}` : "#/automations";

  const header = editable
    ? hdr({
        title: creating ? (story ? "אוטומציית סטורי" : "אוטומציה חדשה") : "עריכה",
        start: `<a class="hdr-btn" href="${back}" id="cancel">ביטול</a>`,
        end: `<button class="hdr-btn strong" id="save">${creating ? "הפעלה" : "שמירה"}</button>`,
        solid: true,
      })
    : hdr({
        title: a.name,
        top: true,
        back: { href: "#/automations", label: "אוטומציות" },
        end: `<a class="btn tinted sm desk-only" href="#/a/${esc(id)}/edit">עריכה</a>
              <button class="hdr-icon" id="more" aria-label="עוד פעולות">${ic("more", 20)}</button>`,
      });

  const top = editable
    ? ""
    : `<div class="hero">
        ${leadThumb(a, post?.picture)}
        <div style="min-width:0"><h1>${esc(a.name)}</h1><div class="sub">${triggerText(a)}</div></div>
      </div>
      <div class="list">
        <div class="item statusrow">
          <div class="body"><div class="title" id="st-t">${active ? "האוטומציה פעילה" : "האוטומציה מושהית"}</div>
            <div class="sub" id="st-s">${active ? "עונה לתגובות עכשיו" : "לא עונה לאף אחד כרגע"}</div></div>
          <label class="switch"><input type="checkbox" id="active" ${active ? "checked" : ""} aria-label="הפעלה והשהיה"><span></span></label>
        </div>
      </div>
      <div class="seg segbar" id="segbar">
        <button data-k="ins" class="sel">נתונים</button>
        <button data-k="build" class="seg-build-only">הגדרות</button>
        <button data-k="pv">תצוגה מקדימה</button>
      </div>`;

  const page = frame(
    "automations",
    `${header}
    <div class="page wide">
      ${top}
      <div class="detail ${editable ? "editing-grid" : ""}" data-seg="${editable ? "build" : "ins"}">
        <aside class="builder">${builderHtml()}<div id="formerr"></div></aside>
        <section class="main-pane">
          ${editable ? "" : `<div class="ins">${insightsHtml()}</div>`}
          <div class="pv"></div>
        </section>
      </div>
    </div>
    ${editable ? `<button class="fab-preview" id="fabpv">${ic("eye", 19, 2)} תצוגה מקדימה</button>` : ""}`,
    { editing: editable },
  );
  const $ = (sel) => page.querySelector(sel);
  const pvEl = $(".pv");

  // ---- markup pieces

  function postThumb() {
    return post?.picture
      ? `<img src="${esc(post.picture)}" alt="" referrerpolicy="no-referrer">`
      : `<div class="ph">${ic("image", 22)}</div>`;
  }

  function storyThumb() {
    return storyPick?.picture
      ? `<img class="st" src="${esc(storyPick.picture)}" alt="" referrerpolicy="no-referrer">`
      : `<div class="ph st">${ic("image", 22)}</div>`;
  }

  function storyTriggerHtml() {
    return `
      <h3>כשמישהו</h3>
      <div class="box">
        <div class="box-label">מגיב לסטורי שלך</div>
        <div class="seg" id="scope">
          <button type="button" data-scope="any" class="${scope === "any" ? "sel" : ""}" ${creating ? "" : "disabled"}>כל סטורי</button>
          <button type="button" data-scope="one" class="${scope === "one" ? "sel" : ""}" ${creating ? "" : "disabled"}>סטורי ספציפי</button>
        </div>
        <div class="post-pick" id="storybox" style="margin-top:12px">
          <span id="storyimg">${storyThumb()}</span>
          ${creating ? `<button type="button" class="btn tinted sm" id="pickstory">${storyPick ? "החלפת סטורי" : "בחירת סטורי"}</button>` : ""}
        </div>
        <div class="note" id="scopenote"></div>
        ${!creating && editable ? `<div class="note">אי אפשר לשנות את הבחירה הזו באוטומציה קיימת. צרו אוטומציה חדשה במקום.</div>` : ""}
      </div>`;
  }

  function builderHtml() {
    const ro = editable ? "" : "readonly";
    const dis = editable ? "" : "disabled";
    return `${
      editable
        ? `<div class="box" style="margin-top:8px"><div class="box-label">שם האוטומציה</div>
            <input class="in" id="name" value="${esc(s.name)}" placeholder="${story ? "למשל: לידים מסטורי מדריך" : "למשל: מדריך — ריל 12/8"}" style="margin:0" dir="auto"></div>`
        : ""
    }
      ${story ? storyTriggerHtml() : `
      <h3>כשמישהו</h3>
      <div class="box">
        <div class="box-label">מגיב על פוסט או ריל ספציפי</div>
        <div class="post-pick"><span id="postimg">${postThumb()}</span>
          ${creating ? `<button type="button" class="btn tinted sm" id="pick">${post ? "החלפת פוסט" : "בחירת פוסט"}</button>` : ""}</div>
        ${!creating && editable ? `<div class="note">אי אפשר להחליף פוסט לאוטומציה קיימת. צרו אוטומציה חדשה במקום.</div>` : ""}
        <hr>
        <div class="box-label">ומגיבים לו בתגובה מתחת לפוסט</div>
        ${[0, 1, 2]
          .map(
            (i) =>
              `<input class="in" data-reply="${i}" ${ro} dir="auto" value="${esc(s.commentReplies[i] || "")}" placeholder="${i ? "נוסח נוסף (לא חובה)" : "למשל: שלחתי לך בפרטי 📩"}">`,
          )
          .join("")}
        <div class="note">כמה נוסחים מתחלפים אקראית, כדי שזה לא ייראה רובוטי.</div>
        <div class="note" id="replynote"></div>
      </div>`}

      <h3>והתגובה כוללת</h3>
      <div class="box">
        ${story ? `<div class="seg" id="anyrep" style="margin-bottom:12px">
          <button type="button" data-any="0" class="${s.anyReply ? "" : "sel"}" ${dis}>מילה מסוימת</button>
          <button type="button" data-any="1" class="${s.anyReply ? "sel" : ""}" ${dis}>כל תגובה</button>
        </div>` : ""}
        <div id="kwbox">
          <div class="box-label">מילה או ביטוי</div>
          <input class="in" id="kw" ${ro} dir="auto" value="${esc(s.keywords.join(", "))}" placeholder="למשל: מדריך" autocomplete="off">
          <div class="seg" id="mm">${Object.entries(MATCH)
            .map(([k, [l]]) => `<button type="button" data-m="${k}" class="${s.matchMode === k ? "sel" : ""}" ${dis}>${l}</button>`)
            .join("")}</div>
          <div class="note" id="mmhint"></div>
          <div id="kwwarn"></div>
        </div>
        <div id="anywarn"></div>
      </div>

      <h3>הוא יקבל</h3>
      <div class="box">
        <div class="row"><div class="box-label">לבקש לעקוב לפני הלינק</div>
          <label class="switch"><input type="checkbox" id="gate" ${s.followGate.enabled ? "checked" : ""} ${dis} aria-label="לעוקבים בלבד"><span></span></label></div>
        <div id="gatebox" style="margin-top:14px">
          <textarea class="in" id="gmsg" ${ro} dir="auto">${esc(s.followGate.message)}</textarea><div class="count" data-count="gmsg"></div>
          <input class="in" id="gbtn" ${ro} dir="auto" value="${esc(s.followGate.buttonLabel)}" placeholder="טקסט הכפתור"><div class="count" data-count="gbtn"></div>
          <div class="box-label">למי שלחץ ועדיין לא עוקב</div>
          <textarea class="in" id="gno" ${ro} dir="auto">${esc(s.followGate.notFollowingMessage)}</textarea><div class="count" data-count="gno"></div>
          <div class="note">הבדיקה אמיתית מול אינסטגרם. רק מי שבאמת עוקב מקבל את הלינק.</div>
        </div>
      </div>

      <h3>ואז הוא יקבל</h3>
      <div class="box">
        <div class="box-label">הודעה עם לינק</div>
        <textarea class="in" id="dm" ${ro} dir="auto">${esc(s.dmMessage)}</textarea><div class="count" data-count="dm"></div>
        <div class="link-in"><input class="in" id="btn" ${ro} dir="auto" value="${esc(s.linkButtonTitle)}" placeholder="טקסט הכפתור, למשל: המדריך אצלך">${ic("link", 17)}</div>
        <div class="count" data-count="btn"></div>
        <div id="btnwarn"></div>
        <input class="in" dir="ltr" id="url" ${ro} value="${esc(s.linkUrl)}" placeholder="https://..." style="margin-bottom:0" aria-label="הלינק">
      </div>
      ${story ? `
      <h3>עוד דברים לאוטומט</h3>
      <div class="box">
        <div class="row"><div class="box-label">❤️ על התגובה שלו לסטורי</div>
          <label class="switch"><input type="checkbox" id="heart" ${s.heart ? "checked" : ""} ${dis} aria-label="תגובת לב"><span></span></label></div>
        <div class="note">מראה לו שראית אותו, עוד לפני שההודעה מגיעה.</div>
      </div>` : ""}`;
  }

  function insightsHtml() {
    const { logs, total, misses } = detail;
    return `
      <div class="tiles">
        ${tile("הופעלו", a.stats.triggered, C.blue, days7(logs))}
        ${tile("נשלחו בפרטי", a.stats.sent, C.green, days7(logs, (l) => l.status === "sent"))}
        ${tile("נכשלו", a.stats.failed, C.red, days7(logs, (l) => l.status === "failed"))}
        ${tile("לא התאימו", misses?.total ?? 0, C.orange)}
      </div>
      ${misses?.total ? `<p class="foot">"לא התאימו": ${story ? "תגובות לסטורי" : "תגובות על הפוסט"} מ-${misses.retentionDays} הימים האחרונים בלי מילת המפתח.</p>` : ""}
      <div class="sec"><h2>מי קיבל מה</h2>${total != null ? `<span class="muted num">${total}</span>` : ""}</div>
      ${
        logs.length
          ? `<div class="list with-avatars">${logs.map((l) => logItem(l)).join("")}</div>`
          : `<div class="list">${emptyState("chat", "עוד אין תגובות", story ? "עוד אף אחד לא הגיב לסטורי מאז שהאוטומציה נוצרה." : "עוד אף אחד לא הגיב עם מילת המפתח מאז שהאוטומציה נוצרה.")}</div>`
      }
      ${post?.permalink ? `<div class="list" style="margin-top:12px"><a class="item center" href="${esc(post.permalink)}" target="_blank" rel="noopener">לפוסט באינסטגרם</a></div>` : ""}`;
  }

  function phoneHtml() {
    const acc = cache.account || {};
    const avatar = acc.picture ? `<img class="pv-av" src="${esc(acc.picture)}" alt="" referrerpolicy="no-referrer">` : `<div class="pv-av"></div>`;
    const kw = story && s.anyReply ? "🔥" : s.keywords[0] || "מילת המפתח";
    const replies = s.commentReplies.filter(Boolean);
    const them = (text, buttons = []) =>
      `<div class="dm them">${avatar.replace("pv-av", "pv-av sm")}<div class="stack">${
        buttons.length
          ? `<div class="card-btns"><div class="b">${esc(text)}</div>${buttons.map((b) => `<div class="qb">${esc(b || "…")}</div>`).join("")}</div>`
          : `<div class="b">${esc(text)}</div>`
      }</div></div>`;
    const me = (t) => `<div class="dm me"><div class="stack"><div class="b">${esc(t)}</div></div></div>`;
    const userHead = `<div class="pv-head">${avatar}<div><div dir="ltr">${esc(acc.username || "")}</div><small>Instagram</small></div></div>`;

    let head;
    let body;
    if (story && pvTab === "story") {
      head = userHead;
      body = `<div class="story-view">${storyPick?.picture ? `<img src="${esc(storyPick.picture)}" alt="" referrerpolicy="no-referrer">` : `<div class="story-ph">${scope === "any" ? "כל סטורי שתעלה" : "בחרו סטורי"}</div>`}
        <div class="story-reply"><span>${esc(kw)}</span><span>➤</span></div></div>`;
    } else if (pvTab === "post") {
      head = userHead;
      body = `<div class="post-view">${post?.picture ? `<img src="${esc(post.picture)}" alt="" referrerpolicy="no-referrer">` : `<img alt="">`}
        <div class="cap"><b dir="ltr">${esc(acc.username || "")}</b> ${esc((post?.caption || "בחרו פוסט כדי לראות אותו כאן").slice(0, 220))}</div></div>`;
    } else if (pvTab === "comments") {
      head = `<div class="pv-head" style="justify-content:center">תגובות</div>`;
      body = `<div class="cmts">
        <div class="cmt"><div class="pv-av"></div><div><b dir="ltr">follower_123</b>${esc(kw)}</div></div>
        ${replies[0] ? `<div class="cmt reply">${avatar}<div><b dir="ltr">${esc(acc.username || "")}</b>${esc(replies[0])}</div></div>` : ""}
        ${replies.length > 1 ? `<div class="sys">מתחלף אקראית עם עוד ${replies.length - 1} נוסחים</div>` : ""}
        ${replies.length ? `<div class="sys">מתפרסם רק אחרי שההודעה הראשונה נשלחה בפרטי</div>` : ""}
      </div>`;
    } else {
      head = userHead;
      let h = "";
      if (story) {
        h += `<div class="dm me"><div class="stack"><div class="sr-label">הגיב/ה לסטורי שלך</div>
          ${storyPick?.picture ? `<img class="sr-thumb" src="${esc(storyPick.picture)}" alt="" referrerpolicy="no-referrer">` : `<div class="sr-thumb"></div>`}
          <div class="b">${esc(kw)}</div>${s.heart ? `<div class="react">❤️</div>` : ""}</div></div>`;
      }
      if (s.followGate.enabled) {
        h += them(s.followGate.message, [s.followGate.buttonLabel]);
        h += me(s.followGate.buttonLabel || "…");
        h += `<div class="sys">בודקים מול אינסטגרם אם הוא עוקב ✓</div>`;
      }
      h += them(s.dmMessage, [s.linkButtonTitle]);
      if (s.followGate.enabled && s.followGate.notFollowingMessage.trim()) {
        h += `<div class="sys">ומי שלחץ ועדיין לא עוקב יקבל:</div>`;
        h += them(s.followGate.notFollowingMessage, [s.followGate.buttonLabel]);
      }
      body = `<div class="dm-body">${h}</div><div class="dm-input">הודעה...</div>`;
    }
    return `<div class="phone-wrap">
      <div class="phone"><div class="screen"><div class="island"></div>
        <div class="statusbar"><span>9:41</span><span>●●●</span></div>${head}${body}</div></div>
      <div class="pv-tabs">${(story ? [["story", "סטורי"], ["dm", "הודעות"]] : [["post", "פוסט"], ["comments", "תגובות"], ["dm", "הודעות"]])
        .map(([k, l]) => `<button type="button" data-pv="${k}" class="${pvTab === k ? "on" : ""}">${l}</button>`)
        .join("")}</div>
    </div>`;
  }

  // ---- behaviour

  function read() {
    s.name = $("#name").value;
    s.keywords = $("#kw").value.split(/[,،\n]/).map((k) => k.trim()).filter(Boolean);
    s.commentReplies = [...page.querySelectorAll("[data-reply]")].map((i) => i.value.trim());
    s.followGate = {
      enabled: $("#gate").checked,
      message: $("#gmsg").value,
      buttonLabel: $("#gbtn").value,
      notFollowingMessage: $("#gno").value,
    };
    s.dmMessage = $("#dm").value;
    s.linkButtonTitle = $("#btn").value;
    s.linkUrl = $("#url").value.trim();
    if (story) s.heart = $("#heart").checked;
  }

  function refresh() {
    if (editable) read();
    $("#gatebox").style.display = s.followGate.enabled ? "" : "none";
    $("#mmhint").textContent = MATCH[s.matchMode]?.[1] || "";
    if (story) {
      $("#kwbox").style.display = s.anyReply ? "none" : "";
      $("#storybox").style.display = scope === "one" ? "" : "none";
      $("#scopenote").textContent =
        scope === "any"
          ? "עובד על כל סטורי שתעלה, כולל סטוריז שנשמרו בהיילייטס."
          : "רק סטוריז שבאוויר עכשיו. כשהסטורי יורד אחרי 24 שעות, האוטומציה מפסיקה לעבוד (אלא אם הוא בהיילייטס, ואז עדיף \"כל סטורי\").";
      $("#anywarn").innerHTML =
        editable && s.anyReply && scope === "any"
          ? `<div class="alert warn">כל מי שיגיב לכל סטורי שלך, גם חבר ששולח סתם אימוג'י, יקבל את ההודעה עם הלינק.</div>`
          : "";
    }
    if ($("#replynote"))
      $("#replynote").textContent = "התגובה הציבורית מתפרסמת רק אחרי שההודעה הראשונה נשלחה אליו בפרטי. אם ההודעה לא נשלחה, לא מגיבים לו בפוסט.";
    const urlish = /https?:|:\/\/|www\.|\.(ai|com|co\.il|io|net|org|me|app)\b/i.test(s.linkButtonTitle);
    $("#btnwarn").innerHTML =
      editable && urlish
        ? `<div class="alert bad">כאן כותבים את הטקסט שיופיע על הכפתור (למשל "לאתר שלי"), לא את הלינק. הלינק נכנס בשדה שמתחת.</div>`
        : "";
    const short = editable && s.matchMode === "contains" ? s.keywords.filter((k) => k.length <= 4) : [];
    $("#kwwarn").innerHTML = short.length
      ? `<div class="alert bad">"${esc(short.join('", "'))}" קצרה מדי ל"מכיל". היא תופיע בתוך מילים אחרות ותשלח הודעות למי שלא ביקש. בחרו "מילה שלמה" או "בדיוק".</div>`
      : "";
    for (const [k, max] of Object.entries(LIMITS)) {
      const left = max - $("#" + k).value.length;
      const el = page.querySelector(`[data-count="${k}"]`);
      el.textContent = left;
      el.className = "count" + (left < 0 ? " over" : "");
    }
    pvEl.innerHTML = phoneHtml();
  }

  pvEl.addEventListener("click", (e) => {
    const b = e.target.closest("[data-pv]");
    if (!b) return;
    pvTab = b.dataset.pv;
    pvEl.innerHTML = phoneHtml();
  });

  if (!editable) {
    const det = $(".detail");
    page.querySelectorAll("#segbar button").forEach((b) => {
      b.onclick = () => {
        page.querySelectorAll("#segbar button").forEach((x) => x.classList.toggle("sel", x === b));
        det.dataset.seg = b.dataset.k;
      };
    });
    const sw = $("#active");
    const setActiveUI = () => {
      $("#st-t").textContent = active ? "האוטומציה פעילה" : "האוטומציה מושהית";
      $("#st-s").textContent = active ? "עונה לתגובות עכשיו" : "לא עונה לאף אחד כרגע";
      sw.checked = active;
    };
    const setActive = async (want) => {
      sw.disabled = true;
      try {
        await api(`/automations/${id}`, { method: "PATCH", body: { isActive: want } });
        active = want;
        toast(want ? "האוטומציה פעילה ✓" : "האוטומציה הושהתה");
      } catch (err) {
        toast(err.message, true);
      }
      setActiveUI();
      sw.disabled = false;
    };
    sw.onchange = () => setActive(sw.checked);
    const del = () =>
      actionSheet(`למחוק את "${a.name}"? המחיקה סופית, והיסטוריית השליחות נמחקת איתה.`, [
        {
          label: "מחיקת האוטומציה",
          danger: true,
          run: async () => {
            try {
              await api(`/automations/${id}`, { method: "DELETE" });
              toast("נמחק");
              location.hash = "#/automations";
            } catch (err) {
              toast(err.message, true);
            }
          },
        },
      ]);
    $("#more").onclick = () =>
      actionSheet(a.name, [
        { label: "עריכה", run: () => (location.hash = `#/a/${id}/edit`) },
        { label: active ? "השהיה" : "הפעלה", run: () => setActive(!active) },
        { label: "מחיקה", danger: true, run: del },
      ]);
    refresh();
    enablePTR(() => route());
    return;
  }

  // ---- editing

  page.querySelectorAll("#mm button").forEach((b) => {
    b.onclick = () => {
      s.matchMode = b.dataset.m;
      dirty = true;
      page.querySelectorAll("#mm button").forEach((x) => x.classList.toggle("sel", x === b));
      refresh();
    };
  });
  page.querySelectorAll(".builder input, .builder textarea").forEach((el) =>
    el.addEventListener("input", () => {
      dirty = true;
      refresh();
    }),
  );
  $("#gate").addEventListener("change", () => ((dirty = true), refresh()));
  $("#heart")?.addEventListener("change", () => ((dirty = true), refresh()));
  $("#pick")?.addEventListener("click", openPicker);
  $("#pickstory")?.addEventListener("click", openStoryPicker);
  page.querySelectorAll("#scope button").forEach((b) => {
    b.onclick = () => {
      scope = b.dataset.scope;
      dirty = true;
      page.querySelectorAll("#scope button").forEach((x) => x.classList.toggle("sel", x === b));
      if (scope === "one" && !storyPick) openStoryPicker();
      refresh();
    };
  });
  page.querySelectorAll("#anyrep button").forEach((b) => {
    b.onclick = () => {
      s.anyReply = b.dataset.any === "1";
      dirty = true;
      page.querySelectorAll("#anyrep button").forEach((x) => x.classList.toggle("sel", x === b));
      refresh();
    };
  });
  $("#cancel").addEventListener("click", (e) => {
    if (!dirty) return;
    e.preventDefault();
    actionSheet("לצאת בלי לשמור? השינויים יאבדו.", [{ label: "יציאה בלי שמירה", danger: true, run: () => (location.hash = back) }]);
  });
  $("#fabpv").onclick = () => {
    read();
    const sh = openSheet({ title: "תצוגה מקדימה", tall: true, body: `<div class="pv-sheet"></div>` });
    const host = sh.el.querySelector(".pv-sheet");
    host.innerHTML = phoneHtml();
    host.addEventListener("click", (e) => {
      const b = e.target.closest("[data-pv]");
      if (!b) return;
      pvTab = b.dataset.pv;
      host.innerHTML = phoneHtml();
      pvEl.innerHTML = phoneHtml();
    });
  };
  refresh();
  if (creating && !story) openPicker();

  function openStoryPicker() {
    const sh = openSheet({
      title: "בחירת סטורי",
      tall: true,
      cancel: "ביטול",
      body: stories.length
        ? `<p class="foot" style="margin:0 2px 12px">הסטוריז שבאוויר עכשיו</p><div class="pgrid">${stories
            .map(
              (st) => `<button type="button" class="pcell story" data-id="${esc(st.id)}">
                ${st.picture ? `<img src="${esc(st.picture)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : ""}
                <span class="tag">${esc(ago(st.createdTime))}</span></button>`,
            )
            .join("")}</div>`
        : emptyState("story", "אין סטוריז באוויר", "אין לך כרגע סטורי פעיל. אפשר לבחור \"כל סטורי\" במקום."),
      onClose: () => {
        if (scope === "one" && !storyPick) {
          scope = "any";
          page.querySelectorAll("#scope button").forEach((x) => x.classList.toggle("sel", x.dataset.scope === "any"));
          refresh();
        }
      },
    });
    sh.el.onclick = (e) => {
      const c = e.target.closest(".pcell");
      if (!c) return;
      storyPick = stories.find((x) => x.id === c.dataset.id);
      s.platformPostId = storyPick.id;
      dirty = true;
      $("#storyimg").innerHTML = storyThumb();
      $("#pickstory").textContent = "החלפת סטורי";
      sh.close();
      refresh();
    };
  }

  function openPicker() {
    const sh = openSheet({
      title: "בחירת פוסט או ריל",
      tall: true,
      cancel: "ביטול",
      body: posts.length
        ? `<div class="pgrid">${posts
            .map((p) => {
              const t = taken.get(p.id);
              return `<button type="button" class="pcell" data-id="${esc(p.id)}" ${t ? "disabled" : ""} title="${esc(t ? "כבר יש כאן אוטומציה פעילה: " + t : p.caption)}">
                ${p.picture ? `<img src="${esc(p.picture)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : ""}
                <span class="tag">${t ? "תפוס" : p.commentCount + " 💬"}</span><span class="cap">${esc(p.caption.slice(0, 80))}</span></button>`;
            })
            .join("")}</div>`
        : emptyState("image", "לא הצלחתי לטעון פוסטים", "פוסט שעלה ממש עכשיו יכול לקחת עד 10 דקות להופיע."),
    });
    sh.el.onclick = (e) => {
      const c = e.target.closest(".pcell");
      if (!c || c.disabled) return;
      post = posts.find((p) => p.id === c.dataset.id);
      s.platformPostId = post.id;
      s.postTitle = post.caption.slice(0, 120);
      dirty = true;
      $("#postimg").innerHTML = postThumb();
      $("#pick").textContent = "החלפת פוסט";
      if (!$("#name").value.trim()) $("#name").value = `${s.keywords[0] || "אוטומציה"} — ${fmtDay(post.createdTime) || "פוסט"}`;
      sh.close();
      refresh();
    };
  }

  $("#save").onclick = async () => {
    read();
    const btn = $("#save");
    btn.disabled = true;
    $("#formerr").innerHTML = "";
    try {
      if (story && scope === "one" && !storyPick) throw new Error("בחרו סטורי, או עברו ל\"כל סטורי\"");
      const payload = {
        trigger: s.trigger,
        anyReply: !!s.anyReply,
        heart: !!s.heart,
        name: s.name,
        platformPostId: story ? (scope === "one" ? storyPick?.id : null) : s.platformPostId,
        postTitle: s.postTitle,
        keywords: s.keywords,
        matchMode: s.matchMode,
        commentReplies: s.commentReplies,
        followGate: s.followGate,
        dmMessage: s.dmMessage,
        linkButtonTitle: s.linkButtonTitle,
        linkUrl: s.linkUrl,
      };
      const { automation } = creating
        ? await api("/automations", { method: "POST", body: payload })
        : await api(`/automations/${id}`, { method: "PATCH", body: payload });
      dirty = false;
      toast(creating ? "האוטומציה נוצרה ופעילה ✓" : "נשמר ✓");
      location.hash = `#/a/${automation.id}`;
    } catch (err) {
      const box = $("#formerr");
      box.innerHTML = `<div class="alert bad">${esc(err.message)}</div>`;
      toast("יש מה לתקן לפני השמירה", true);
      box.scrollIntoView({ behavior: "smooth", block: "center" });
      btn.disabled = false;
    }
  };
}

// --------------------------------------------------------------- contacts

async function renderContacts() {
  loading("contacts", "אנשי קשר");
  const [{ account }, { items }] = await Promise.all([api("/automations"), api("/activity")]);
  cache.account = account;
  const people = new Map();
  for (const i of items) {
    const k = i.commenterId || i.who;
    const p = people.get(k) || { who: i.who, last: i, count: 0 };
    p.count++;
    people.set(k, p);
  }
  const all = [...people.values()];

  const page = frame(
    "contacts",
    `${hdr({ title: "אנשי קשר", top: true })}
    <div class="page">
      <h1 class="large-title">אנשי קשר</h1>
      <div class="toolbar"><label class="search">${ic("search", 17)}<input id="q" type="search" placeholder="חיפוש לפי שם" aria-label="חיפוש אנשי קשר" autocomplete="off"></label></div>
      <div id="tbl"></div>
      <p class="foot">${all.length} אנשי קשר. כל מי שהגיב עם מילת מפתח לאחת האוטומציות.</p>
    </div>`,
  );
  const draw = () => {
    const q = page.querySelector("#q").value.trim().toLowerCase();
    const shown = all.filter((p) => !q || (p.who || "").toLowerCase().includes(q));
    page.querySelector("#tbl").innerHTML = shown.length
      ? `<div class="list with-avatars">${shown
          .map((p) => {
            const [label, cls] = STATUS[p.last.status] || ["—", "off"];
            return `<div class="item">
              <span class="avatar" style="background:${avatarColor(p.who)}">${initial(p.who)}</span>
              <div class="body"><div class="title" dir="auto">${esc(p.who || "משתמש")}</div>
                <div class="sub">"${esc(p.last.text)}"${p.count > 1 ? ` · ${p.count} פעמים` : ""} · ${esc(p.last.automationName || "")}</div></div>
              <div class="trail"><span>${ago(p.last.at)}</span><span class="pill ${cls}">${esc(label)}</span></div>
            </div>`;
          })
          .join("")}</div>`
      : `<div class="list">${
          all.length
            ? emptyState("search", "לא נמצא", "אף איש קשר לא מתאים לחיפוש.")
            : emptyState("contacts", "עוד אין אנשי קשר", "ברגע שמישהו יגיב עם מילת מפתח, הוא יופיע כאן.")
        }</div>`;
  };
  page.querySelector("#q").addEventListener("input", draw);
  draw();
  enablePTR(() => route());
}

// --------------------------------------------------------------- settings

async function renderSettings() {
  loading("settings", "הגדרות");
  const { account } = await api("/automations");
  cache.account = account;
  const info = (icon, color, title, text) =>
    `<div class="item"><span class="item-icon" style="background:${color}">${ic(icon, 17, 2.1)}</span>
      <div class="body"><div class="title">${title}</div><div class="sub wrap" style="-webkit-line-clamp:4">${text}</div></div></div>`;
  const page = frame(
    "settings",
    `${hdr({ title: "הגדרות", top: true })}
    <div class="page">
      <h1 class="large-title">הגדרות</h1>
      <div class="list">
        ${
          account
            ? `<div class="item" style="padding-block:14px">${
                account.picture
                  ? `<img class="avatar" style="width:56px;height:56px" src="${esc(account.picture)}" alt="" referrerpolicy="no-referrer">`
                  : `<span class="avatar" style="width:56px;height:56px;background:${avatarColor(account.username)}">${initial(account.username)}</span>`
              }
                <div class="body"><div class="title" style="font-size:19px;font-weight:600" dir="ltr">@${esc(account.username)}</div>
                <div class="sub">אינסטגרם · ${account.connected ? "מחובר" : "מנותק, צריך לחבר מחדש ב-zernio.com"}</div></div>
                <span class="pill ${account.connected ? "on" : "bad"}">${account.connected ? "מחובר" : "מנותק"}</span></div>`
            : `<div class="item"><div class="body"><div class="title">אינסטגרם לא מחובר</div><div class="sub">מחברים אותו ב-zernio.com</div></div></div>`
        }
      </div>

      <div class="sec"><h2>אבטחה</h2></div>
      <div class="list">
        <div class="item"><span class="item-icon" style="background:var(--green)">${bioIcon(18)}</span>
          <div class="body"><div class="title">כניסה עם ${bioName()}</div><div class="sub" id="biosub">בודק...</div></div>
          <label class="switch"><input type="checkbox" id="bioswitch" disabled aria-label="כניסה ביומטרית"><span></span></label></div>
        ${info("lock", "var(--indigo)", "ההתחברות נשמרת 30 יום", "במכשיר הזה. אחרי זה נכנסים שוב, עם סיסמה או זיהוי ביומטרי.")}
      </div>
      <div id="bioerr"></div>

      <div class="sec"><h2>איך זה עובד</h2></div>
      <div class="list">
        ${info("cloud", "var(--accent)", "רץ 24/7 בענן", "על השרתים של Zernio ושל Vercel. גם כשהמחשב והטלפון כבויים.")}
        ${info("reply", "var(--purple)", "תגובה ציבורית רק אחרי הודעה בפרטי", "\"אצלך בפרטי\" מתפרסם רק אחרי שההודעה הראשונה באמת נשלחה. אם לא נשלחה, לא מגיבים בפוסט.")}
        ${info("pin", "var(--orange)", "כל אוטומציה צמודה לפוסט אחד", "אף פעם לא לכל החשבון, כדי שתגובה על פוסט ישן לא תקבל הודעה לא קשורה.")}
        ${info("shield", "var(--green)", "לינקים נשלחים כמו שהם", "בלי עטיפת מעקב קליקים, שנראית לאינסטגרם כמו ספאם.")}
      </div>

      <div class="list" style="margin-top:28px"><button class="item danger" id="logout">התנתקות</button></div>
      <p class="foot" style="text-align:center;margin-top:16px">האוטומציות שלי</p>
    </div>`,
  );
  page.querySelector("#logout").onclick = () =>
    actionSheet("להתנתק מהמכשיר הזה?", [
      {
        label: "התנתקות",
        danger: true,
        run: async () => {
          await api("/login", { method: "DELETE" }).catch(() => {});
          cache.authed = false;
          renderLogin();
        },
      },
    ]);

  const sw = page.querySelector("#bioswitch");
  const sub = page.querySelector("#biosub");
  const draw = async () => {
    if (!(await bioAvailable())) {
      sub.textContent = "המכשיר או הדפדפן הזה לא תומכים בזה";
      sw.disabled = true;
      sw.checked = false;
      return;
    }
    const on = !!store.get(PK_KEY);
    sw.disabled = false;
    sw.checked = on;
    sub.textContent = on ? "פעיל במכשיר הזה" : "במקום להקליד סיסמה";
  };
  sw.onchange = async () => {
    page.querySelector("#bioerr").innerHTML = "";
    if (sw.checked) {
      sw.disabled = true;
      try {
        await enableBio();
        toast(`${bioName()} הופעל ✓`);
      } catch (err) {
        page.querySelector("#bioerr").innerHTML = `<div class="alert bad">${esc(bioError(err))}</div>`;
      }
    } else {
      store.del(PK_KEY);
      store.del(PK_SKIP);
      toast("בוטל במכשיר הזה");
    }
    draw();
  };
  draw();
}

// ----------------------------------------------------------------- router

async function route() {
  const h = location.hash.replace(/^#/, "") || "/home";
  try {
    if (cache.authed === null) cache.authed = (await api("/login")).authed;
    if (!cache.authed) return renderLogin();
    let m;
    if (h === "/home" || h === "/") return await renderHome();
    if (h === "/automations") return await renderAutomations();
    if (h === "/contacts") return await renderContacts();
    if (h === "/settings") return await renderSettings();
    if (h === "/new" || h === "/new/comment") return await renderAutomation(null, "new", "comment");
    if (h === "/new/story") return await renderAutomation(null, "new", "story_reply");
    if ((m = h.match(/^\/a\/([\w-]+)\/edit$/))) return await renderAutomation(m[1], "edit");
    if ((m = h.match(/^\/a\/([\w-]+)$/))) return await renderAutomation(m[1], "view");
    location.hash = "#/home";
  } catch (e) {
    if (e.message === "צריך להתחבר מחדש") return;
    const page = frame(
      "",
      `${hdr({ title: "" })}<div class="page">${emptyState(
        "refresh",
        "משהו השתבש",
        esc(e.message),
        `<button class="btn tinted" id="retry">לנסות שוב</button>`,
      )}</div>`,
    );
    page.querySelector("#retry").onclick = () => route();
  }
}

// Screen transitions: push deeper, pop back, cross-fade between tabs.
const depth = (h) => (/^\/(a\/[\w-]+\/edit|new)/.test(h) ? 2 : /^\/a\//.test(h) ? 1 : 0);
let lastHash = location.hash.replace(/^#/, "") || "/home";
function go(dir) {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (!document.startViewTransition || reduce) {
    window.scrollTo(0, 0);
    return route();
  }
  document.documentElement.dataset.vt = dir;
  const t = document.startViewTransition(
    () =>
      new Promise((resolve) => {
        firstPaint = () => {
          window.scrollTo(0, 0);
          resolve();
        };
        setTimeout(resolve, 700);
        route();
      }),
  );
  t.finished.finally(() => delete document.documentElement.dataset.vt);
}
window.addEventListener("hashchange", () => {
  const h = location.hash.replace(/^#/, "") || "/home";
  const d1 = depth(lastHash);
  const d2 = depth(h);
  lastHash = h;
  closeSheets();
  go(d2 > d1 ? "fwd" : d2 < d1 ? "back" : "fade");
});

// Desktop shortcuts: N = new automation, / = search.
document.addEventListener("keydown", (e) => {
  if (e.metaKey || e.ctrlKey || e.altKey || e.target.closest?.("input, textarea, select") || !cache.authed) return;
  if (document.querySelector(".sheet-wrap")) return;
  if (e.key === "n" || e.key === "מ") {
    e.preventDefault();
    openNewChooser();
  } else if (e.key === "/") {
    const q = document.querySelector("#q");
    if (q) {
      e.preventDefault();
      q.focus();
    }
  }
});

route();
