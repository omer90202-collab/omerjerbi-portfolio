import { guard, zernio, env, toLogView } from "./_lib.js";

// Every trigger across all automations, newest first — feeds the home screen
// and the contacts list. Zernio keeps logs per automation, so this fans out.
export default guard(async (req, res) => {
  const accountId = env("ZERNIO_ACCOUNT_ID");
  const autos = ((await zernio("GET", `/comment-automations?profileId=${env("ZERNIO_PROFILE_ID")}`)).automations || [])
    .filter((a) => !a.accountId || a.accountId === accountId);
  const perAuto = await Promise.all(
    autos.map((a) => {
      const id = a.id || a._id;
      return zernio("GET", `/comment-automations/${id}/logs?limit=100`)
        .then((d) => (d.logs || []).map((l) => ({ ...toLogView(l), automationId: id, automationName: a.name })))
        .catch(() => []);
    }),
  );
  const items = perAuto.flat().sort((x, y) => String(y.at || "").localeCompare(String(x.at || "")));
  res.status(200).json({ items });
});
