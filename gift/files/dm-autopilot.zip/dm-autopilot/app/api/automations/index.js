import { guard, zernio, env, httpError, buildAutomation, storyConflict, toView } from "../_lib.js";
import { writeExtra, adoptNativeReply } from "../_store.js";

export default guard(async (req, res) => {
  if (req.method === "GET") {
    const [autos, accounts] = await Promise.all([
      zernio("GET", `/comment-automations?profileId=${env("ZERNIO_PROFILE_ID")}`),
      zernio("GET", "/accounts"),
    ]);
    const accountId = env("ZERNIO_ACCOUNT_ID");
    const list = (accounts.accounts || (Array.isArray(accounts) ? accounts : []));
    const ig = list.find((a) => (a._id || a.id) === accountId) || null;
    return res.status(200).json({
      account: ig && {
        username: ig.username || "",
        picture: ig.profilePicture || ig.profilePictureUrl || ig.avatar || null,
        connected: ig.isActive !== false,
      },
      automations: (
        await Promise.all(
          (autos.automations || [])
            .filter((a) => !a.accountId || a.accountId === accountId)
            .map((a) => adoptNativeReply(a).catch(() => a)),
        )
      ).map((a) => toView(a)),
    });
  }

  if (req.method === "POST") {
    const trigger = req.body?.trigger === "story_reply" ? "story_reply" : "comment";
    const { body, extra } = buildAutomation(req.body || {}, { creating: true, trigger });
    if (trigger === "story_reply") {
      const existing = (await zernio("GET", `/comment-automations?profileId=${env("ZERNIO_PROFILE_ID")}`)).automations || [];
      const clash = storyConflict(existing.map((a) => ({ ...a, id: a.id || a._id })), body);
      if (clash) throw httpError(409, `כבר יש אוטומציה פעילה ("${clash}") שעונה לאותן תגובות לסטורי. שנו מילת מפתח או השהו אותה, כדי שאף אחד לא יקבל שתי הודעות.`);
    }
    const data = await zernio("POST", "/comment-automations", body);
    const auto = data.automation || data;
    await writeExtra(auto.id || auto._id, extra);
    return res.status(200).json({ automation: toView(auto, extra) });
  }

  res.status(405).json({ error: "לא נתמך" });
});
