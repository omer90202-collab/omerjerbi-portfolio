import { guard, zernio, env, httpError, buildAutomation, storyConflict, toView, toLogView } from "../_lib.js";
import { readExtra, writeExtra, deleteExtra, adoptNativeReply } from "../_store.js";

export default guard(async (req, res) => {
  const id = String(req.query.id || "");
  if (!/^[a-zA-Z0-9_-]{6,64}$/.test(id)) throw httpError(400, "מזהה לא תקין");
  const path = `/comment-automations/${id}`;

  if (req.method === "GET") {
    const [detail, logs] = await Promise.all([zernio("GET", path), zernio("GET", `${path}/logs?limit=100`)]);
    const auto = await adoptNativeReply(detail.automation || detail);
    return res.status(200).json({
      automation: toView(auto, await readExtra(id)),
      logs: (logs.logs || []).map(toLogView),
      total: logs.pagination?.total ?? null,
      misses: logs.misses || null,
    });
  }

  if (req.method === "PATCH") {
    const input = req.body || {};
    // A bare { isActive } is the on/off switch; anything else is a full edit.
    const onlyToggle = Object.keys(input).length === 1 && typeof input.isActive === "boolean";
    if (onlyToggle) {
      if (input.isActive) {
        const current = await zernio("GET", path).then((d) => d.automation || d);
        const existing = (await zernio("GET", `/comment-automations?profileId=${env("ZERNIO_PROFILE_ID")}`)).automations || [];
        const clash = storyConflict(existing.map((a) => ({ ...a, id: a.id || a._id })), { ...current, id });
        if (clash) throw httpError(409, `אי אפשר להפעיל: "${clash}" כבר עונה לאותן תגובות לסטורי. השהו אותה קודם, כדי שאף אחד לא יקבל שתי הודעות.`);
      }
      const data = await zernio("PATCH", path, { isActive: input.isActive });
      return res.status(200).json({ automation: toView(data.automation || data, await readExtra(id)) });
    }
    // The trigger comes from Zernio, never from the form: it can't be changed on edit.
    const current = await zernio("GET", path).then((d) => d.automation || d);
    const trigger = current.trigger === "story_reply" ? "story_reply" : "comment";
    const { body, extra } = buildAutomation(input, { creating: false, trigger });
    if (trigger === "story_reply" && current.isActive !== false) {
      const existing = (await zernio("GET", `/comment-automations?profileId=${env("ZERNIO_PROFILE_ID")}`)).automations || [];
      const clash = storyConflict(existing.map((a) => ({ ...a, id: a.id || a._id })), {
        id,
        trigger,
        platformPostId: current.platformPostId,
        keywords: body.keywords,
      });
      if (clash) throw httpError(409, `כבר יש אוטומציה פעילה ("${clash}") שעונה לאותן תגובות לסטורי. שנו מילת מפתח או השהו אותה, כדי שאף אחד לא יקבל שתי הודעות.`);
    }
    await writeExtra(id, extra);
    const data = await zernio("PATCH", path, body);
    return res.status(200).json({ automation: toView(data.automation || data, extra) });
  }

  if (req.method === "DELETE") {
    await zernio("DELETE", path);
    await deleteExtra(id);
    return res.status(200).json({ ok: true });
  }

  res.status(405).json({ error: "לא נתמך" });
});
