import { guard, zernio, env } from "./_lib.js";

// What an automation can be attached to.
//   /api/posts               recent Instagram posts and reels. Zernio caches this
//                            list for up to 10 minutes, so a post published a
//                            moment ago may take a few minutes to show up.
//   /api/posts?kind=stories  stories that are live right now (Instagram keeps
//                            them for 24 hours).
export default guard(async (req, res) => {
  const accountId = env("ZERNIO_ACCOUNT_ID");
  if (req.query.kind === "stories") {
    const data = await zernio("GET", `/accounts/${accountId}/instagram/stories`);
    const stories = (data.data || []).map((s) => ({
      id: s.id,
      picture: s.thumbnailUrl || s.mediaUrl || null,
      permalink: s.permalink || null,
      createdTime: s.timestamp || null,
      mediaType: s.mediaType || null,
    }));
    return res.status(200).json({ stories });
  }
  const q = new URLSearchParams({ platform: "instagram", accountId, limit: "40" });
  const data = await zernio("GET", `/inbox/comments?${q}`);
  const posts = (data.data || [])
    .filter((p) => !p.isAd)
    .map((p) => ({
      id: p.id,
      caption: p.content || "",
      picture: p.picture || null,
      permalink: p.permalink || null,
      createdTime: p.createdTime || null,
      commentCount: p.commentCount || 0,
    }));
  res.status(200).json({ posts });
});
