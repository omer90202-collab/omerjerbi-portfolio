// Zernio calls this for every new comment (`comment.received`, for the public
// reply) and every incoming DM (`message.received`, for ❤️ on story replies).
// Zernio wants an answer within 5 seconds, so we verify the signature, answer
// at once, and do the waiting in the background (waitUntil).
import crypto from "node:crypto";
import { waitUntil } from "@vercel/functions";
import { handleComment, handleStoryReply } from "./_replier.js";

function signatureOk(raw, given) {
  const secret = process.env.ZERNIO_WEBHOOK_SECRET;
  if (!secret || !given) return false;
  const want = crypto.createHmac("sha256", secret).update(raw).digest("hex");
  return want.length === given.length && crypto.timingSafeEqual(Buffer.from(want), Buffer.from(given));
}

export async function POST(request) {
  const raw = await request.text();
  if (!signatureOk(raw, request.headers.get("x-zernio-signature"))) {
    return new Response("bad signature", { status: 401 });
  }
  let event;
  try {
    event = JSON.parse(raw);
  } catch {
    return new Response("bad json", { status: 400 });
  }
  const work = event.event === "message.received" ? handleStoryReply(event) : handleComment(event);
  waitUntil(
    work
      .then((r) => console.log(`[webhook ${event.id}] ${event.event} ${event.comment?.id || event.message?.id || ""}: ${r}`))
      .catch((e) => console.error(`[webhook ${event.id}] failed:`, e.message)),
  );
  return new Response("ok");
}
