// Face ID / Touch ID login with passkeys (WebAuthn).
//
// Stateless on purpose: there is no database. When a device enables biometric
// login, the server verifies the new passkey and hands back a signed "ticket"
// holding its public key. The device keeps the ticket and sends it with every
// biometric login; the server checks the ticket's signature (only it can make
// one) and then the passkey's signature (only the device's secure chip can make
// one). A stolen ticket is useless without the fingerprint/face behind the key.
import crypto from "node:crypto";
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} from "@simplewebauthn/server";
import { isAuthed, sessionCookie, seal, unseal, readCookieValue, httpError } from "./_lib.js";

const TICKET = "passkey-ticket";
const CHALLENGE = "passkey-challenge";
const CHAL_COOKIE = "adm_chal";

// The passkey is bound to the exact site it was made on.
function site(req) {
  const origin = String(req.headers.origin || "");
  const host = process.env.PUBLIC_HOST || process.env.VERCEL_PROJECT_PRODUCTION_URL || "";
  if (origin === `https://${host}`) return { origin, rpID: host };
  if (/^http:\/\/localhost(:\d+)?$/.test(origin)) return { origin, rpID: "localhost" };
  throw httpError(403, "כתובת לא מורשית");
}

function setChallenge(res, challenge, kind) {
  const token = seal(CHALLENGE, { challenge, kind, exp: Date.now() + 5 * 60_000 });
  res.setHeader("Set-Cookie", `${CHAL_COOKIE}=${token}; Path=/api; HttpOnly; Secure; SameSite=Strict; Max-Age=300`);
}

function takeChallenge(req, kind) {
  const c = unseal(CHALLENGE, readCookieValue(req, CHAL_COOKIE));
  if (!c || c.kind !== kind) throw httpError(403, "פג תוקף הבקשה, נסו שוב");
  return c.challenge;
}

const clearChallenge = `${CHAL_COOKIE}=; Path=/api; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;

function readTicket(raw) {
  const t = unseal(TICKET, raw);
  if (!t?.id || !t?.pk) throw httpError(403, "הזיהוי הביומטרי במכשיר הזה כבר לא תקף. היכנסו עם הסיסמה והפעילו אותו מחדש.");
  return t;
}

const issueTicket = (t) => seal(TICKET, t);

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  try {
    if (req.method !== "POST" || !String(req.headers["content-type"] || "").includes("application/json")) {
      throw httpError(415, "בקשה לא תקינה");
    }
    const { action, ticket, credential, device } = req.body || {};
    const { origin, rpID } = site(req);

    // ------------------------------------------------ enable on this device
    // Only someone already logged in (with the password) can add a passkey.
    if (action === "register-options") {
      if (!isAuthed(req)) throw httpError(401, "צריך להתחבר מחדש");
      const existing = ticket ? unseal(TICKET, ticket) : null;
      const options = await generateRegistrationOptions({
        rpName: "האוטומציות שלי",
        rpID,
        userName: `owner · ${String(device || "מכשיר").slice(0, 30)}`,
        userDisplayName: process.env.OWNER_NAME || "בעלים",
        // A fresh user id per device, so enabling on the iPhone never
        // overwrites the passkey the Mac is using (iCloud syncs both).
        userID: crypto.randomBytes(16),
        attestationType: "none",
        excludeCredentials: existing ? [{ id: existing.id, transports: existing.t }] : [],
        authenticatorSelection: { residentKey: "preferred", userVerification: "required", authenticatorAttachment: "platform" },
        supportedAlgorithmIDs: [-7, -257],
      });
      setChallenge(res, options.challenge, "register");
      return res.status(200).json({ options });
    }

    if (action === "register-verify") {
      if (!isAuthed(req)) throw httpError(401, "צריך להתחבר מחדש");
      const expectedChallenge = takeChallenge(req, "register");
      const v = await verifyRegistrationResponse({
        response: credential,
        expectedChallenge,
        expectedOrigin: origin,
        expectedRPID: rpID,
        requireUserVerification: true,
      }).catch((e) => {
        console.error("passkey verify:", e.message);
        throw httpError(403, "האימות נכשל");
      });
      if (!v.verified) throw httpError(403, "האימות נכשל");
      const c = v.registrationInfo.credential;
      res.setHeader("Set-Cookie", clearChallenge);
      return res.status(200).json({
        ticket: issueTicket({
          id: c.id,
          pk: Buffer.from(c.publicKey).toString("base64url"),
          c: c.counter,
          t: c.transports || [],
          d: String(device || "").slice(0, 30),
          iat: Date.now(),
        }),
      });
    }

    // ------------------------------------------------------------- log in
    if (action === "login-options") {
      const t = readTicket(ticket);
      const options = await generateAuthenticationOptions({
        rpID,
        allowCredentials: [{ id: t.id, transports: t.t }],
        userVerification: "required",
      });
      setChallenge(res, options.challenge, "login");
      return res.status(200).json({ options });
    }

    if (action === "login-verify") {
      const t = readTicket(ticket);
      if (credential?.id !== t.id) throw httpError(403, "המפתח לא תואם למכשיר הזה");
      const expectedChallenge = takeChallenge(req, "login");
      const v = await verifyAuthenticationResponse({
        response: credential,
        expectedChallenge,
        expectedOrigin: origin,
        expectedRPID: rpID,
        credential: { id: t.id, publicKey: Buffer.from(t.pk, "base64url"), counter: t.c, transports: t.t },
        requireUserVerification: true,
      }).catch((e) => {
        console.error("passkey verify:", e.message);
        throw httpError(403, "האימות נכשל");
      });
      if (!v.verified) throw httpError(403, "האימות נכשל");
      res.setHeader("Set-Cookie", [clearChallenge, sessionCookie()]);
      return res.status(200).json({ ok: true, ticket: issueTicket({ ...t, c: v.authenticationInfo.newCounter }) });
    }

    throw httpError(400, "פעולה לא מוכרת");
  } catch (e) {
    return res.status(e.status || 500).json({ error: e.message || "שגיאה" });
  }
}
