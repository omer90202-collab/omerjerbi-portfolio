// Per-automation settings Zernio has no field for (today: the public reply
// texts, which this app posts itself — see api/webhook.js). Private Vercel Blob
// in production; a local folder when LOCAL_STORE_DIR is set (dev only).
import fs from "node:fs/promises";
import path from "node:path";
import { get, put, del } from "@vercel/blob";
import { zernio } from "./_lib.js";

const key = (id) => `automations/${id}.json`;
const local = () => process.env.LOCAL_STORE_DIR;

export async function readExtra(id) {
  try {
    if (local()) return JSON.parse(await fs.readFile(path.join(local(), `${id}.json`), "utf8"));
    const r = await get(key(id), { access: "private", useCache: false });
    if (!r || r.statusCode !== 200) return {};
    return JSON.parse(await new Response(r.stream).text());
  } catch {
    return {};
  }
}

export async function writeExtra(id, data) {
  const body = JSON.stringify({ ...data, updatedAt: new Date().toISOString() });
  if (local()) {
    await fs.mkdir(local(), { recursive: true });
    return fs.writeFile(path.join(local(), `${id}.json`), body);
  }
  await put(key(id), body, {
    access: "private",
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: "application/json",
    cacheControlMaxAge: 60,
  });
}

export async function deleteExtra(id) {
  try {
    if (local()) return await fs.rm(path.join(local(), `${id}.json`), { force: true });
    await del(key(id));
  } catch {}
}

// Any automation that still has Zernio's own public reply switched on (made
// before this rule existed, or created outside the dashboard) is moved over:
// texts into our store first, then Zernio's copy cleared, so Zernio can never
// post it and nothing is lost if either step fails.
export async function adoptNativeReply(auto) {
  const native = [auto.commentReply, ...(auto.commentReplyVariations || [])].filter(Boolean);
  if (!native.length) return auto;
  const id = auto.id || auto._id;
  const extra = await readExtra(id);
  if (!extra.replies?.length) await writeExtra(id, { ...extra, replies: native });
  await zernio("PATCH", `/comment-automations/${id}`, { commentReply: "", commentReplyVariations: [] });
  return { ...auto, commentReply: null, commentReplyVariations: [] };
}
