import { passwordOk, sessionCookie, clearedCookie, isAuthed } from "./_lib.js";

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  try {
    if (req.method === "GET") return res.status(200).json({ authed: isAuthed(req) });
    if (req.method === "DELETE") {
      res.setHeader("Set-Cookie", clearedCookie);
      return res.status(200).json({ ok: true });
    }
    if (req.method !== "POST") return res.status(405).json({ error: "לא נתמך" });
    if (!passwordOk(req.body?.password)) {
      // Slow down guessing; the password is long enough that this is a courtesy.
      await new Promise((r) => setTimeout(r, 800));
      return res.status(401).json({ error: "סיסמה שגויה" });
    }
    res.setHeader("Set-Cookie", sessionCookie());
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(e.status || 500).json({ error: e.message });
  }
}
