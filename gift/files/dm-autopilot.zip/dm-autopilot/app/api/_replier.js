// The public reply rule, enforced here and nowhere else:
//
//   1. someone comments the keyword
//   2. Zernio sends them the FIRST private message
//   3. only once Zernio confirms that message went out do we reply publicly
//
// If the private message fails (or never happens), there is no public reply —
// so nobody is ever told "check your DMs" when nothing is waiting there.
import { zernio, env } from "./_lib.js";
import { readExtra, adoptNativeReply } from "./_store.js";

const WAIT_MS = 90_000;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Loose on purpose: a comment that does not even contain the keyword can never
// match Zernio's stricter modes, so we skip it without polling. Anything that
// passes still waits for Zernio's own verdict in the logs.
function normalize(t) {
  return String(t || "")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[֑-ׇ]/g, "") // niqqud
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}
const mightMatch = (text, keywords) => keywords.some((k) => normalize(k) && normalize(text).includes(normalize(k)));

// Zernio statuses that mean a private message really went out:
//   gated = the follow-gate message was sent; sent = the link message was sent.
const DM_OUT = new Set(["gated", "sent"]);

async function alreadyReplied(postId, commentId) {
  const q = new URLSearchParams({ accountId: env("ZERNIO_ACCOUNT_ID"), limit: "100" });
  const d = await zernio("GET", `/inbox/comments/${postId}?${q}`);
  const c = (d.comments || d.data || []).find((x) => x.id === commentId);
  return !!c?.replies?.some((r) => r.from?.isOwner);
}

export async function handleComment(event, { dryRun = false } = {}) {
  const c = event?.comment;
  if (event?.event !== "comment.received" || !c) return "skip: not a comment event";
  if (c.platform !== "instagram") return "skip: not instagram";
  const accountId = env("ZERNIO_ACCOUNT_ID");
  if ((event.account?.accountId || event.account?.id) !== accountId) return "skip: other account";
  if (c.author?.isOwnAccount) return "skip: our own comment";

  const autos = (await zernio("GET", `/comment-automations?profileId=${env("ZERNIO_PROFILE_ID")}`)).automations || [];
  const auto = autos.find(
    (a) => a.isActive !== false && a.platformPostId === c.platformPostId && (a.trigger || "comment") === "comment",
  );
  if (!auto) return "skip: no active automation on this post";
  if (!mightMatch(c.text, auto.keywords || [])) return "skip: keyword not in comment";
  const id = auto.id || auto._id;
  if (!dryRun) await adoptNativeReply(auto);
  const { replies = [] } = await readExtra(id);
  if (!replies.length) return "skip: no public reply set for this automation";

  // Wait for Zernio to finish with this comment's first private message.
  let entry;
  const until = Date.now() + WAIT_MS;
  await sleep(dryRun ? 0 : 4000);
  while (Date.now() < until) {
    const logs = (await zernio("GET", `/comment-automations/${id}/logs?limit=100`)).logs || [];
    entry = logs.find((l) => l.commentId === c.id);
    if (entry && entry.status !== "pending") break;
    await sleep(3000);
  }
  if (!entry) return "no reply: Zernio never handled this comment";
  if (!DM_OUT.has(entry.status)) return `no reply: private message not sent (${entry.status}${entry.error ? `: ${entry.error}` : ""})`;
  if (await alreadyReplied(c.platformPostId, c.id)) return "no reply: already answered";

  const message = replies[Math.floor(Math.random() * replies.length)];
  if (dryRun) return `would reply: ${message}`;
  await zernio(
    "POST",
    `/inbox/comments/${c.platformPostId}`,
    { accountId, message, commentId: c.id },
    // Same key for every delivery of this comment: a retried webhook can
    // never produce a second public reply.
    { "Idempotency-Key": `autodm-reply-${c.id}` },
  );
  return `replied: ${message}`;
}

// ❤️ on story replies ("React to story replies with ❤️"). Zernio's
// story_reply automation sends the DMs; this only adds the heart, and only to
// replies that one of our live story automations answers, when it has ❤️ on.
export async function handleStoryReply(event, { dryRun = false } = {}) {
  const m = event?.message;
  if (event?.event !== "message.received" || !m) return "skip: not a message event";
  if (m.platform !== "instagram" || m.direction !== "incoming") return "skip: not an incoming instagram message";
  const accountId = env("ZERNIO_ACCOUNT_ID");
  if ((event.account?.accountId || event.account?.id) !== accountId) return "skip: other account";

  const autos = ((await zernio("GET", `/comment-automations?profileId=${env("ZERNIO_PROFILE_ID")}`)).automations || [])
    .filter((a) => a.isActive !== false && a.trigger === "story_reply")
    .filter((a) => !(a.keywords || []).length || mightMatch(m.text, a.keywords));
  if (!autos.length) return "skip: no story automation matches this message";
  const withHeart = [];
  for (const a of autos) if ((await readExtra(a.id || a._id)).heart) withHeart.push(a);
  if (!withHeart.length) return "skip: ❤️ is off";

  // The webhook normally says which story was replied to; if it doesn't, the
  // stored message does.
  let storyId = m.storyReply?.storyId;
  if (!storyId && m.conversationId) {
    const q = new URLSearchParams({ accountId, limit: "10" });
    const d = await zernio("GET", `/inbox/conversations/${m.conversationId}/messages?${q}`);
    const found = (d.messages || d.data || []).find((x) => x.id === m.id || x.platformMessageId === m.platformMessageId);
    storyId = found?.storyReply?.storyId;
  }
  if (!storyId) return "skip: not a story reply";
  // A rule for this exact story wins over an any-story rule, as in Zernio.
  const auto = withHeart.find((a) => a.platformPostId === storyId) || withHeart.find((a) => !a.platformPostId);
  if (!auto) return "skip: no ❤️ automation for this story";
  if (dryRun) return `would react ❤️ (${auto.name})`;
  await zernio("POST", `/inbox/conversations/${m.conversationId}/messages/${m.id}/reactions`, { accountId, emoji: "❤️" });
  return `reacted ❤️ (${auto.name})`;
}
