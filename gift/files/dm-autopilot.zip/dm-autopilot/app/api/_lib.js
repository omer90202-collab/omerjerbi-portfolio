// Shared server helpers: session auth, the Zernio client, and the safety rules
// every automation must pass before it reaches Instagram.
import crypto from "node:crypto";

const ZERNIO = "https://zernio.com/api/v1";
const COOKIE = "adm_session";
const MAX_AGE = 60 * 60 * 24 * 30; // 30 days

export function env(key) {
  const v = process.env[key];
  if (!v) throw httpError(500, `חסר משתנה סביבה ${key}`);
  return v;
}

export function httpError(status, message, details) {
  return Object.assign(new Error(message), { status, details });
}

// ------------------------------------------------------------------ session

function sign(value) {
  return crypto.createHmac("sha256", env("SESSION_SECRET")).update(value).digest("base64url");
}

export function sessionCookie() {
  const exp = String(Date.now() + MAX_AGE * 1000);
  return `${COOKIE}=${exp}.${sign(exp)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${MAX_AGE}`;
}

export const clearedCookie = `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;

export function isAuthed(req) {
  const token = readCookieValue(req, COOKIE);
  if (!token) return false;
  const [exp, sig] = token.split(".");
  if (!exp || !sig || Number(exp) < Date.now()) return false;
  const good = sign(exp);
  return sig.length === good.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good));
}

// Tamper-proof envelopes for small server-issued data (passkey tickets, WebAuthn
// challenges). The purpose is part of the signed message so one kind can never
// be replayed as another, or as a session token.
export function seal(purpose, obj) {
  const body = Buffer.from(JSON.stringify(obj)).toString("base64url");
  return `${body}.${sign(`${purpose}|${body}`)}`;
}

export function unseal(purpose, token) {
  const [body, sig] = String(token || "").split(".");
  if (!body || !sig) return null;
  const good = sign(`${purpose}|${body}`);
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
  try {
    const obj = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    return obj.exp && obj.exp < Date.now() ? null : obj;
  } catch {
    return null;
  }
}

export function readCookieValue(req, name) {
  for (const part of (req.headers.cookie || "").split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k === name) return v.join("=");
  }
  return null;
}

export function passwordOk(input) {
  // Hash both sides so the comparison is constant-time regardless of length.
  const a = crypto.createHash("sha256").update(String(input ?? "")).digest();
  const b = crypto.createHash("sha256").update(env("DASHBOARD_PASSWORD")).digest();
  return crypto.timingSafeEqual(a, b);
}

// Wraps a route: no caching, login required, JSON-only writes (blocks
// cross-site form posts), and errors come back as { error } in Hebrew.
export function guard(handler) {
  return async (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    try {
      if (!isAuthed(req)) throw httpError(401, "צריך להתחבר מחדש");
      if (req.method !== "GET" && !String(req.headers["content-type"] || "").includes("application/json")) {
        throw httpError(415, "בקשה לא תקינה");
      }
      await handler(req, res);
    } catch (e) {
      res.status(e.status || 500).json({ error: e.message || "שגיאה", details: e.details });
    }
  };
}

// ------------------------------------------------------------------- zernio

export async function zernio(method, path, body, headers = {}) {
  const r = await fetch(ZERNIO + path, {
    method,
    headers: {
      Authorization: `Bearer ${env("ZERNIO_API_KEY")}`,
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await r.text();
  let data;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { error: text.slice(0, 500) };
  }
  if (!r.ok) {
    const msg = data.error || data.message || `Zernio החזיר ${r.status}`;
    throw httpError(r.status >= 500 ? 502 : r.status, typeof msg === "string" ? msg : JSON.stringify(msg), data);
  }
  return data;
}

// ------------------------------------------------------------ safety rules

const MATCH_MODES = ["contains", "word", "exact"];
const units = (s) => String(s ?? "").length; // JS length = UTF-16 units, which is what Meta counts

function clean(s) {
  return String(s ?? "").trim();
}

// Turns the dashboard's form into a Zernio comment-automation body, refusing
// anything that could DM people who never asked. Same rules as the skill's
// `audit`: short keywords never substring-match, every comment rule is scoped
// to one post, and links go out untouched (a redirect wrapper reads as spam in
// DMs). Story-reply rules may cover every story — a story reply is a message the
// person chose to send, and a story has no post to scope to.
//
// Returns { body, extra }: `extra` is what Zernio has no field for and
// api/_store.js keeps (public reply texts for comments, the ❤️ switch for stories).
export function buildAutomation(input, { creating, trigger }) {
  const errors = [];
  const story = trigger === "story_reply";
  const anyReply = story && input.anyReply === true;
  const name = clean(input.name);
  const keywords = anyReply ? [] : [...new Set((input.keywords || []).map(clean).filter(Boolean))];
  const matchMode = input.matchMode;
  const replies = story ? [] : (input.commentReplies || []).map(clean).filter(Boolean);
  const storyId = story ? clean(input.platformPostId) : "";
  const gate = input.followGate || {};
  const dmMessage = clean(input.dmMessage);
  const buttonTitle = clean(input.linkButtonTitle);
  const url = clean(input.linkUrl);

  if (!name) errors.push("חסר שם לאוטומציה");
  if (units(name) > 80) errors.push("השם ארוך מדי (עד 80 תווים)");
  if (creating && !story && !/^\d+$/.test(clean(input.platformPostId))) errors.push("צריך לבחור פוסט");
  if (creating && story && storyId && !/^\d+$/.test(storyId)) errors.push("הסטורי שנבחר לא תקין");
  if (!keywords.length && !anyReply) errors.push("צריך לפחות מילת מפתח אחת, או לבחור \"כל תגובה\"");
  if (keywords.length > 10) errors.push("עד 10 מילות מפתח");
  if (!MATCH_MODES.includes(matchMode)) errors.push("סוג התאמה לא תקין");
  if (matchMode === "contains") {
    for (const k of keywords) {
      if (units(k) <= 4) {
        errors.push(`"${k}" קצרה מדי להתאמה מסוג "מכיל" — היא תופיע בתוך מילים אחרות ותשלח הודעות למי שלא ביקש. בחרו "מילה שלמה" או "בדיוק".`);
      }
    }
  }
  if (replies.length > 6) errors.push("עד 6 נוסחים לתגובה הציבורית");
  if (replies.some((r) => units(r) > 300)) errors.push("תגובה ציבורית ארוכה מדי (עד 300 תווים)");
  if (!dmMessage) errors.push("חסר טקסט להודעה עם הלינק");
  if (units(dmMessage) > 640) errors.push("ההודעה עם הלינק ארוכה מדי (עד 640 תווים)");
  if (!buttonTitle) errors.push("חסר טקסט לכפתור הלינק");
  if (units(buttonTitle) > 20) errors.push("טקסט כפתור הלינק ארוך מדי (עד 20 תווים, אימוג'י נחשב 2)");
  if (/https?:|:\/\/|www\.|\.(ai|com|co\.il|io|net|org|me|app)\b/i.test(buttonTitle)) {
    errors.push("בשדה של הכפתור כותבים את הטקסט שיופיע עליו (למשל \"לאתר שלי\"), לא את הלינק. הלינק נכנס בשדה שמתחתיו.");
  }
  let parsed;
  try {
    parsed = new URL(url);
  } catch {}
  if (!parsed || parsed.protocol !== "https:") errors.push("הלינק חייב להתחיל ב-https://");

  if (gate.enabled) {
    if (!clean(gate.message)) errors.push("חסרה הודעת בקשת המעקב");
    if (units(clean(gate.message)) > 640) errors.push("הודעת בקשת המעקב ארוכה מדי (עד 640 תווים)");
    if (!clean(gate.buttonLabel)) errors.push("חסר טקסט לכפתור \"עקבתי\"");
    if (units(clean(gate.buttonLabel)) > 20) errors.push("כפתור \"עקבתי\" ארוך מדי (עד 20 תווים)");
    if (units(clean(gate.notFollowingMessage)) > 640) errors.push("ההודעה למי שלא עוקב ארוכה מדי (עד 640 תווים)");
  }
  if (errors.length) throw httpError(400, errors.join("\n"));

  const body = {
    name,
    keywords,
    matchMode,
    dmMessage,
    buttons: [{ type: "url", title: buttonTitle, url: parsed.href }],
    linkTracking: false,
    // The public reply is never Zernio's: it would only go out after the link
    // (i.e. after the follow gate). api/webhook.js posts it the moment the
    // FIRST private message is confirmed sent, and never if it was not.
    commentReply: "",
    commentReplyVariations: [],
    audience: gate.enabled
      ? { followerStatus: "follower", whenUnknown: "verify" }
      : { followerStatus: "any", whenUnknown: "send" },
  };
  if (gate.enabled) {
    body.followGate = {
      message: clean(gate.message),
      buttonLabel: clean(gate.buttonLabel),
      ...(clean(gate.notFollowingMessage) ? { notFollowingMessage: clean(gate.notFollowingMessage) } : {}),
    };
  }
  if (story) body.matchMode = anyReply ? "contains" : matchMode;
  if (creating) {
    Object.assign(body, {
      profileId: env("ZERNIO_PROFILE_ID"),
      accountId: env("ZERNIO_ACCOUNT_ID"),
      trigger: story ? "story_reply" : "comment",
      ...(story ? (storyId ? { platformPostId: storyId } : {}) : { platformPostId: clean(input.platformPostId) }),
      postTitle: clean(input.postTitle).slice(0, 120),
    });
    delete body.commentReply;
    delete body.commentReplyVariations;
  }
  return { body, extra: story ? { heart: input.heart === true } : { replies } };
}

// Two live story rules that both answer the same reply would send two DMs.
// Stories have no per-post uniqueness to lean on, so check it here.
const norm = (k) => String(k || "").normalize("NFKC").toLowerCase().trim();
export function storyConflict(existing, candidate) {
  if (candidate.trigger !== "story_reply") return null;
  for (const a of existing) {
    if (a.trigger !== "story_reply" || a.isActive === false || a.id === candidate.id) continue;
    if ((a.platformPostId || null) !== (candidate.platformPostId || null)) continue;
    const ka = (a.keywords || []).map(norm);
    const kb = (candidate.keywords || []).map(norm);
    const overlap = !ka.length || !kb.length || ka.some((x) => kb.some((y) => x.includes(y) || y.includes(x)));
    if (overlap) return a.name;
  }
  return null;
}

// The shape the dashboard reads, whatever Zernio calls its fields. `extra` is
// what api/_store.js keeps for the automation (the public reply texts).
export function toView(a, extra = {}) {
  const s = a.stats || {};
  const story = a.trigger === "story_reply";
  return {
    id: a.id || a._id,
    name: a.name,
    isActive: a.isActive !== false,
    trigger: story ? "story_reply" : "comment",
    anyReply: story && !(a.keywords || []).length,
    heart: story && extra.heart === true,
    platformPostId: a.platformPostId || null,
    postTitle: a.postTitle || "",
    keywords: a.keywords || [],
    matchMode: a.matchMode || "contains",
    commentReplies: extra.replies ?? [a.commentReply, ...(a.commentReplyVariations || [])].filter(Boolean),
    followGate: {
      enabled: (a.audience?.followerStatus || "any") === "follower",
      message: a.followGate?.message || "",
      buttonLabel: a.followGate?.buttonLabel || "",
      notFollowingMessage: a.followGate?.notFollowingMessage || "",
    },
    dmMessage: a.dmMessage || "",
    linkButtonTitle: a.buttons?.[0]?.title || "",
    linkUrl: a.buttons?.[0]?.url || "",
    linkTracking: !!a.linkTracking,
    stats: {
      triggered: s.totalTriggered ?? s.triggered ?? 0,
      sent: s.totalSent ?? s.dmsSent ?? 0,
      failed: s.totalFailed ?? s.dmsFailed ?? 0,
    },
    createdAt: a.createdAt || null,
    updatedAt: a.updatedAt || a.createdAt || null,
  };
}

export function toLogView(l) {
  return {
    id: l.id,
    at: l.createdAt,
    who: l.commenterName || "",
    commenterId: l.commenterId || null,
    text: l.commentText || "",
    source: l.source || "comment",
    status: l.status,
    audience: l.audienceOutcome || null,
    isFollower: l.commenterIsFollower ?? null,
    error: l.error || null,
    commentReplyStatus: l.commentReplyStatus || null,
  };
}
