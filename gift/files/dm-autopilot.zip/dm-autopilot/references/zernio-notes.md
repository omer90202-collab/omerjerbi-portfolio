# Zernio — what this skill uses

Checked against docs.zernio.com on 2026-10-01. If something breaks, the docs win over this file.

- Base URL: `https://zernio.com/api/v1` (Quickstart). Override with `ZERNIO_BASE_URL` in `.env`.
  Note: one Zernio blog post shows `https://api.zernio.com/v1`; the docs say `zernio.com/api/v1`.
- Auth: `Authorization: Bearer sk_...` (key = `sk_` + 64 hex). Created in Dashboard -> API Keys,
  shown once.

## Endpoints

| Command | Method + path | Source |
|---|---|---|
| `profiles` | `GET /v1/profiles` | docs: profiles/list-profiles |
| `accounts` | `GET /v1/accounts?platform=instagram` | docs: accounts/list-accounts |
| `connect` | `GET /v1/connect/instagram?profileId=` -> `authUrl` | docs: connect/get-connect-url |
| `posts`, `find-post` | `GET /v1/accounts/{accountId}/posts` (25 latest, `id` + `permalink`) | docs: accounts/get-account-posts |
| `push` (new) | `POST /v1/comment-automations` | docs: comment-automations/create |
| `push` (existing), `pause`, `resume` | `PATCH /v1/comment-automations/{id}` | docs: comment-automations/update |
| `rules` | `GET /v1/comment-automations?profileId=` | docs: comment-automations/list |
| `show` | `GET /v1/comment-automations/{id}` | docs: comment-automations/get |
| `logs` | `GET /v1/comment-automations/{id}/logs` | docs: comment-automations/list-logs |
| `remove` | `DELETE /v1/comment-automations/{id}` | docs: comment-automations/delete |

## Fields we send (create)

`profileId`, `accountId`, `name`, `trigger: "comment"`, `platformPostId`, `postTitle`, `keywords`,
`matchMode` (`word` | `exact` | `contains`), `excludeKeywords`, `typoTolerance` (word mode, 4+ chars),
`alsoMatchInDms`, `dmMessage` (<=640 with buttons), `buttons: [{type:"url", title(<=20), url}]`,
`dmMessageVariations` (<=5), `dmDelaySeconds` (0-86400), `linkTracking`, `commentReply`,
`commentReplyVariations` (<=5), `audience`, `followGate {message, buttonLabel, notFollowingMessage}`.

Follow-gate mapping:
- `off` -> no `audience`.
- `verify` -> `audience: {followerStatus:"follower", whenUnknown:"verify"}`.
- `tap` -> `audience: {followerStatus:"any", tapToUnlock:true}`.

## Verified vs. uncertain

Verified in the docs: all paths above, request field names and limits, 409 when a per-post
automation already exists, PATCH clears arrays with `[]` and delay with `0`, account-wide when
`platformPostId` is omitted, Instagram needs a Business/Creator account, 7-day private-reply
window and one private reply per comment (Zernio blog).

Not fully verified (handled defensively in code):
- Exact JSON shape of the `/profiles` list and the `/logs` items. The script reads several likely
  keys and falls back to printing raw JSON.
- `id` vs `_id` on automations — the script accepts both.
- How to clear an existing `commentReply` via PATCH — not documented, so the script doesn't try.
- Whether a comment from the account owner triggers the automation — test from a second account.
- Meta's DM rate limits — not published as a firm number; don't promise one.
- Instagram menu names for "Allow access to messages" can move between app versions.
- Pricing (2 free accounts, then per-account) — changes; check zernio.com/pricing.
